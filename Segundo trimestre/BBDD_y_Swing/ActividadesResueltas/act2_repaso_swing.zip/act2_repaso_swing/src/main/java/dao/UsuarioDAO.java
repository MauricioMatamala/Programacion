package dao;

import modelo.Usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private DBConn dbConn;
    public UsuarioDAO() throws SQLException {
        dbConn = new DBConn();
    }

    public boolean create(Usuario usuario) throws SQLException {
        dbConn.queryUpdate("INSERT INTO usuarios(nombre,edad) VALUES ('"+usuario.getNombre()+"','"+usuario.getEdad()+"')");
        ResultSet result = dbConn.query("SELECT id FROM usuarios WHERE nombre='"+usuario.getNombre()+"'");
        if (result.next()){
            usuario.setId(result.getInt("id"));
            return true;
        } else {
            return false;
        }
    }

    public List<Usuario> readAll() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        ResultSet result = dbConn.query("SELECT * FROM usuarios");
        while (result.next()){
            Usuario usuario = new Usuario(result.getString("nombre"),result.getInt("edad"));
            usuario.setId(result.getInt("id"));
            lista.add(usuario);
        }
        return lista;
    }

    public Usuario readById(int id) throws SQLException {
        ResultSet result = dbConn.query("SELECT * FROM usuarios WHERE id='"+id+"'");
        if (result.next()){
            Usuario usuario = new Usuario(result.getString("nombre"),result.getInt("edad"));
            usuario.setId(result.getInt("id"));
            return usuario;
        } else {
            return null;
        }
    }

    public boolean update(Usuario usuario) throws SQLException {
        int filasAfectadas = dbConn.queryUpdate("UPDATE usuarios SET nombre='"+usuario.getNombre()+"', edad='"+usuario.getEdad()+"' WHERE id='"+usuario.getId()+"'");
         return (filasAfectadas == 1);
    }

    public boolean delete(Usuario usuario) throws SQLException {
        int filasAfectadas = dbConn.queryUpdate("DELETE FROM usuarios WHERE id='"+usuario.getId()+"'");
        return (filasAfectadas == 1);
    }

    public void deleteAll() throws SQLException {
        int filasAfectadas = dbConn.queryUpdate("DELETE FROM usuarios");
    }
}
