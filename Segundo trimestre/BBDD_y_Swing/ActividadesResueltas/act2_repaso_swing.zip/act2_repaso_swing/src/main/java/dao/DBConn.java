package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConn {
    private Connection dbConn;

    public DBConn() throws SQLException {
        dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Usuarios?serverTimezone=UTC","usuariosuser","Perro20");
    }

    public ResultSet query(String sql) throws SQLException {
        return dbConn.prepareStatement(sql).executeQuery();
    }

    public int queryUpdate(String sql) throws SQLException {
        return dbConn.prepareStatement(sql).executeUpdate();
    }

}
