import dao.UsuarioDAO;
import jdk.swing.interop.SwingInterOpUtils;
import modelo.Usuario;

import java.sql.SQLException;
import java.util.List;

public class App {
    public static void main(String[] args) throws SQLException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        usuarioDAO.deleteAll();

        Usuario usuario1 = new Usuario("Pedro García",33);
        Usuario usuario2 = new Usuario("Carlos Orozco",15);
        Usuario usuario3 = new Usuario("Ana López",21);

        usuarioDAO.create(usuario1);
        usuarioDAO.create(usuario2);
        usuarioDAO.create(usuario3);

        List<Usuario> lista = usuarioDAO.readAll();
        System.out.println(lista);

        usuario1.setEdad(23);
        usuarioDAO.update(usuario1);

        Usuario usuario1_actualizado = usuarioDAO.readById(usuario1.getId());
        System.out.println(usuario1_actualizado);

        usuarioDAO.delete(usuario3);
        lista = usuarioDAO.readAll();
        System.out.println(lista);

    }
}
