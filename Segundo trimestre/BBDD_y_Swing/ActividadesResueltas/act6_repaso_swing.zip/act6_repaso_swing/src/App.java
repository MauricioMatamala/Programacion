import javax.swing.*;

public class App {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ejemplo con un diálogo"); // Marco de la aplicación.
        frame.setContentPane(new ListaNumeros().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
