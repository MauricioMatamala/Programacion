import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ListaNumeros {
    private JPanel pnlMain;
    private JList lstNumeros;
    private JButton btnNuevoNumero;
    private DefaultListModel<Integer> listModel;

    public ListaNumeros(){
        listModel = new DefaultListModel<Integer>();
        lstNumeros.setModel(listModel);

        btnNuevoNumero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                DataTransfer datos = new DataTransfer();
                DialogoNuevoNumero dialogo = new DialogoNuevoNumero(datos);
                dialogo.pack();
                dialogo.setLocationRelativeTo(pnlMain);
                dialogo.setVisible(true); // Hasta que no se oculta el diálogo, la ejecución se queda parada aquí.

                listModel.addElement(datos.numero);
            }
        });
    }

    public Container getPanel() {
        return pnlMain;
    }
}
