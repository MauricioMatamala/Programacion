public class DataTransfer {
    public int numero;
}
