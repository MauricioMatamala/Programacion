package org.example.controlador;

import org.example.dao.UsuarioDAO;
import org.example.modelo.Usuario;

import java.sql.SQLException;
import java.util.List;

public class ControladorUsuarios {
    public boolean crearUsuario(String nombre, int edad) throws SQLException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        return usuarioDAO.create(new Usuario(nombre,edad));
    }

    public List<Usuario> getUsuarios() throws SQLException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        return usuarioDAO.readAll();
    }
}
