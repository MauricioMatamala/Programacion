package org.example.vista;

import org.example.controlador.ControladorUsuarios;
import org.example.modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class VistaUsuarios {
    private JList lstUsuarios;
    private JButton btnActualizar;
    private JPanel pnlMain;
    private DefaultListModel<Usuario> modeloLista;
    private ControladorUsuarios controladorUsuarios;
    public VistaUsuarios(){
        modeloLista = new DefaultListModel<>();
        lstUsuarios.setModel(modeloLista);

        controladorUsuarios = new ControladorUsuarios();

        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    List<Usuario> lista = controladorUsuarios.getUsuarios();
                    for (Usuario usuario : lista) {
                        modeloLista.addElement(usuario);
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
    }

    public Container getPanel() {
        return pnlMain;
    }
}
