import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Numeros {
    private JPanel pnlMain;
    private JSpinner spnNumero;
    private JButton btnSumar;
    private JButton btnRestar;
    private JTextField txtResultado;
    private int sumaTotal = 0;

    public Numeros(){
        btnSumar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int numero = (Integer) spnNumero.getValue();
                sumaTotal += numero;
                txtResultado.setText(String.valueOf(sumaTotal));
            }
        });

        btnRestar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int numero = (Integer) spnNumero.getValue();
                sumaTotal -= numero;
                txtResultado.setText(String.valueOf(sumaTotal));
            }
        });

    }

    public Container getPanel() {
        return pnlMain;
    }
}
