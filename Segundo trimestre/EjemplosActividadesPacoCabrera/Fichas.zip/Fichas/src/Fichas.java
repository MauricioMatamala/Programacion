import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fichas {
    private JPanel panelMain;
    private JButton butFicha;
    private JLabel Ficha;
    private JLabel Extraida;
    private JTextField txtFicha;
    private JTextField txtRojas;
    private JTextField txtVerdes;
    private JTextField txtAzules;
    private int rojas;
    private int verdes;
    private int azules;


    public int randomizarFicha() {
        int numero;
        numero = (int)(Math.random()*3+1);
        return numero;
    }

    public Fichas() {
        txtRojas.setText("0");
        txtAzules.setText("0");
        txtVerdes.setText("0");
        rojas = Integer.parseInt(txtRojas.getText());
        azules = Integer.parseInt(txtAzules.getText());
        verdes = Integer.parseInt(txtVerdes.getText());



        butFicha.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int numRandom = randomizarFicha();
                if (numRandom == 1) {
                    txtFicha.setBackground(Color.RED);
                    rojas++;
                    txtRojas.setText(String.valueOf(rojas));

                }
                    else if (numRandom == 2) {
                        txtFicha.setBackground(Color.GREEN);
                        verdes++;
                        txtVerdes.setText(String.valueOf(verdes));
                }
                else if (numRandom == 3) {
                    txtFicha.setBackground(Color.BLUE);
                    azules++;
                    txtAzules.setText(String.valueOf(azules));
                }

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Colección de Fichas");
        frame.setContentPane(new Fichas().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
