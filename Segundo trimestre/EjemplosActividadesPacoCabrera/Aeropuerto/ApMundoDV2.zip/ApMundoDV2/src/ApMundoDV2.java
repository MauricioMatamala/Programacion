import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ApMundoDV2 {
    private JPanel panelMain;
    private JLabel lblPaises1;
    private JComboBox listaPaises1;
    private JButton butCalcular;
    private JTextArea txtAeropuertos;
    private JLabel lblInfo;
    private JLabel lblAp1;
    private JComboBox listaAp1;
    private JLabel lblPaises2;
    private JComboBox listaPaises2;
    private JLabel lblAp2;
    private JComboBox listaAp2;
    private JTextField txtDistancia;
    private static Document xmlDoc = null;
    private static ArrayList<String> paises = new ArrayList<String>();
    static long inicio;
    private String dir = System.getProperty("user.dir");
    private static float lat1, lon1, lat2, lon2;
    private String ap;
    private float lat, lon;
    private ArrayList<ApMundoDV2> aeropuertos1 = new ArrayList<>();
    private ArrayList<ApMundoDV2> aeropuertos2 = new ArrayList<>();

    public ApMundoDV2(String ap, float lat, float lon) {
        this.ap = ap;
        this.lat = lat;
        this.lon = lon;
    }

    public String getAp() {
        return ap;
    }

    public float getLat() {
        return lat;
    }

    public float getLon() {
        return lon;
    }

    public ApMundoDV2 findBN(String ap, ArrayList<ApMundoDV2> aeropuertos) {
        for (ApMundoDV2 aero : aeropuertos) {
            if (aero.getAp().equals(ap)) {
                return aero;
            }
        }
        return null;
    }

    public ApMundoDV2() {
        //Para conseguir las listas con todos los paises.
        try {
            File inputFile = new File(dir + File.separator + "aeropuertos.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("aeropuerto");
            for (int n = nodeList.getLength() - 1; n >= 0; n--) {
                Node nodo = nodeList.item(n);
                short nodeType = nodo.getNodeType();
                if (nodeType == Node.ELEMENT_NODE) {
                    String aerop = nodo.getAttributes().getNamedItem("pais").getNodeValue().trim();
                    paises.add(aerop);
                }
            }
            //Eliminamos los elementos repetidos.
            Set<String> hs = new HashSet<>();
            hs.addAll(paises);
            paises.clear();
            paises.addAll(hs);
            //
            Collections.sort(paises);
            paises.forEach((pais) -> {
                listaPaises1.addItem(pais);
                listaPaises2.addItem(pais);
            });
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        //Cogemos las 2 longitudes y latitudes de cada aeropuerto y realizamos la operación (con objetos).
        butCalcular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String apS1 = listaAp1.getSelectedItem().toString();
                String apS2 = listaAp2.getSelectedItem().toString();
                ApMundoDV2 aeros1 = new ApMundoDV2("", 0, 0);
                ApMundoDV2 aeros2 = new ApMundoDV2("", 0, 0);
                lat1 = aeros1.findBN(apS1, aeropuertos1).getLat();
                lon1 = aeros1.findBN(apS1, aeropuertos1).getLon();
                lat2 = aeros2.findBN(apS2, aeropuertos2).getLat();
                lon2 = aeros2.findBN(apS2, aeropuertos2).getLon();
                double theta = lon1 - lon2;
                double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
                dist = Math.acos(dist);
                dist = rad2deg(dist);
                dist = dist * 60 * 1.1515;
                dist = dist * 1.609344;
                txtDistancia.setText(dist + "Km");
            }
        });


        listaPaises1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paises.clear();
                aeropuertos1.clear();
                listaAp1.removeAllItems();
                String paisSel1 = listaPaises1.getSelectedItem().toString();
                XPath xPath = XPathFactory.newInstance().newXPath();
                try {
                    File inputFile = new File(dir + File.separator + "aeropuertos.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();
                    XPathExpression expression1 = xPath.compile("//aeropuerto[@pais='" + paisSel1 + "']");
                    NodeList nodeList = (NodeList) expression1.evaluate(doc, XPathConstants.NODESET);
                    System.out.println("nodos " + nodeList.getLength());
                    for (int n = nodeList.getLength() - 1; n >= 0; n--) {
                        Node nodo = nodeList.item(n);
                        short nodeType = nodo.getNodeType();
                        if (nodeType == Node.ELEMENT_NODE) {
                            String lat = (nodo.getAttributes().getNamedItem("lat").getNodeValue());
                            String lon = (nodo.getAttributes().getNamedItem("lon").getNodeValue());
                            String aerop = nodo.getAttributes().getNamedItem("nombreCorto").getNodeValue();
                            float latx = Float.valueOf(lat);
                            float lonx = Float.valueOf(lon);
                            paises.add(aerop);
                            aeropuertos1.add(new ApMundoDV2(aerop, latx, lonx));
                        }
                    }
                    Collections.sort(paises);
                    paises.forEach((pais) -> listaAp1.addItem(pais));
                } catch (XPathExpressionException f) {
                    f.printStackTrace();
                } catch (SAXException f) {
                    f.printStackTrace();
                } catch (IOException f) {
                    f.printStackTrace();
                } catch (ParserConfigurationException f) {
                    f.printStackTrace();
                }
            }
        });
        listaPaises2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paises.clear();
                aeropuertos2.clear();
                listaAp2.removeAllItems();
                String paisSel2 = listaPaises2.getSelectedItem().toString();
                XPath xPath = XPathFactory.newInstance().newXPath();
                try {
                    File inputFile = new File(dir + File.separator + "aeropuertos.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();
                    XPathExpression expression1 = xPath.compile("//aeropuerto[@pais='" + paisSel2 + "']");
                    NodeList nodeList = (NodeList) expression1.evaluate(doc, XPathConstants.NODESET);
                    System.out.println("nodos " + nodeList.getLength());
                    for (int n = nodeList.getLength() - 1; n >= 0; n--) {
                        Node nodo = nodeList.item(n);
                        short nodeType = nodo.getNodeType();
                        if (nodeType == Node.ELEMENT_NODE) {
                            String lat = (nodo.getAttributes().getNamedItem("lat").getNodeValue());
                            String lon = (nodo.getAttributes().getNamedItem("lon").getNodeValue());
                            String aerop = nodo.getAttributes().getNamedItem("nombreCorto").getNodeValue();
                            float latx = Float.valueOf(lat);
                            float lonx = Float.valueOf(lon);
                            paises.add(aerop);
                            aeropuertos2.add(new ApMundoDV2(aerop, latx, lonx));
                        }
                    }
                    Collections.sort(paises);
                    paises.forEach((pais) -> listaAp2.addItem(pais));
                } catch (XPathExpressionException f) {
                    f.printStackTrace();
                } catch (SAXException f) {
                    f.printStackTrace();
                } catch (IOException f) {
                    f.printStackTrace();
                } catch (ParserConfigurationException f) {
                    f.printStackTrace();
                }
            }
        });
    }

    //Métodos para pasar grados a radianes y viceversa.
    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }


    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Distancia entre aeropuertos V2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new ApMundoDV2().panelMain);
        frame.setSize(550, 300);
        //frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
