En este proyecto podéis ver:

- Un ejemplo de tranferencia de datos entre una ventana y un diálogo.
- Una forma de utilizar el Swing UI Designer de IntelliJ para diseñar un Renderer.
