package com.politecnicomalaga.vista;

import com.politecnicomalaga.modelo.Persona;

import javax.swing.*;
import java.awt.*;

public class PersonaRender implements ListCellRenderer<Persona> {
    private JLabel lblEdad;
    private JLabel lblCategoría;
    private JLabel lblApellidos;
    private JLabel lblNombre;
    private JPanel pnlMain;
    private JPanel pnlCategoria;
    private JPanel pnlNombreApellidos;

    @Override
    public Component getListCellRendererComponent(JList<? extends Persona> jList, Persona persona, int i, boolean isSelected, boolean cellHasFocus) {
        lblApellidos.setText(persona.getApellidos());
        lblNombre.setText(persona.getNombre());
        lblEdad.setText(String.valueOf(persona.getEdad()));
        lblCategoría.setText(persona.getNombreCategoria());

        Color fondoPanel = Color.WHITE;

        if (persona.getCategoria() == Persona.CLASE_A)
            fondoPanel = new Color(200,200,200);
        else if (persona.getCategoria() == Persona.CLASE_B)
            fondoPanel = new Color(51,153,255);
        else if (persona.getCategoria() == Persona.CLASE_C)
            fondoPanel = new Color(255,153,0);


        pnlMain.setBackground(fondoPanel);
        pnlNombreApellidos.setBackground(fondoPanel);
        pnlCategoria.setBackground(fondoPanel);
        return pnlMain;
    }
}
