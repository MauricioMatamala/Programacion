package com.politecnicomalaga.modelo;

public class Persona {
    public final static int CLASE_A = 0;
    public final static int CLASE_B = 1;
    public final static int CLASE_C = 2;
    private String nombre;
    private String apellidos;
    private int edad;
    private int categoria;

    public Persona(String nombre, String apellidos, int edad, int categoria) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getCategoria() {
        return categoria;
    }

    public String getNombreCategoria(){
        if (categoria == CLASE_A)
            return "Clase A";
        else if (categoria == CLASE_B)
            return "Clase B";
        else
            return "Clase C";
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", edad=" + edad +
                ", categoria=" + categoria +
                '}';
    }
}
