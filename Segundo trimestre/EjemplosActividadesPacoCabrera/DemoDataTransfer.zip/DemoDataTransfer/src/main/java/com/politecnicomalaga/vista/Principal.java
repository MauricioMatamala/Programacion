package com.politecnicomalaga.vista;

import com.politecnicomalaga.modelo.Persona;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal {
    private JPanel pnlMain;
    private JList lstPersonas;
    private JButton btnNuevo;
    private DefaultListModel<Persona> modeloPersonas;
    public Principal(){
        btnNuevo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                DataTransfer datos = new DataTransfer();
                DialogoNuevaPersona dialogo = new DialogoNuevaPersona(datos);
                Persona persona = DataTransferAPersona.transformar(datos);
                modeloPersonas.addElement(persona);
            }
        });
    }

    public JPanel getPanel(){
        return pnlMain;
    }

    private void createUIComponents() {
        lstPersonas = new JList();
        modeloPersonas = new DefaultListModel<>();
        lstPersonas.setModel(modeloPersonas);
        lstPersonas.setCellRenderer(new PersonaRender());
    }
}
