package com.politecnicomalaga.vista;

import com.politecnicomalaga.modelo.Persona;

public class DataTransferAPersona {
    public static Persona transformar(DataTransfer datos){
        String nombre = (String) datos.get("nombre");
        String apellidos = (String) datos.get("apellidos");
        int edad = (Integer) datos.get("edad");
        int categoría = (Integer) datos.get("categoría");
        return new Persona(nombre,apellidos,edad,categoría);
    }
}
