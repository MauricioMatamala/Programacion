package com.politecnicomalaga.vista;

import com.politecnicomalaga.modelo.Persona;

import javax.swing.*;
import java.awt.event.*;

public class DialogoNuevaPersona extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JSpinner spnEdad;
    private JComboBox cmbCategoría;
    private DataTransfer datos;

    public DialogoNuevaPersona(DataTransfer datos) {
        this.datos = datos;
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        setLocationRelativeTo(SwingUtilities.getRoot(null));
        pack();
        setVisible(true);
    }

    private void onOK() {
        datos.put("nombre",txtNombre.getText());
        datos.put("apellidos",txtApellidos.getText());
        datos.put("edad",spnEdad.getValue());

        if (cmbCategoría.getSelectedItem().toString().equals("A"))
            datos.put("categoría",Persona.CLASE_A);
        else if (cmbCategoría.getSelectedItem().toString().equals("B"))
            datos.put("categoría",Persona.CLASE_B);
        else
            datos.put("categoría",Persona.CLASE_C);

        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    private void createUIComponents() {
        cmbCategoría = new JComboBox();
        cmbCategoría.addItem("A");
        cmbCategoría.addItem("B");
        cmbCategoría.addItem("C");
    }
}
