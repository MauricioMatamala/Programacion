import javax.swing.*;

public class App {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Dialogos"); // Marco de la aplicación.
        frame.setContentPane(new Principal().getPanel()); // Alturas: nombre del Form enmarcado y de su clase correspondiente.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
