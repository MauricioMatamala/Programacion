import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal {
    private JTextField txtValor;
    private JPanel pnlPrincipal;
    private JButton btnOk;
    private JLabel lblValor;

    public Principal(){
        btnOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String valor = txtValor.getText();
                Dialogo dialogo = new Dialogo();
                String valorModificado = dialogo.getValorMoficado(valor);
                lblValor.setText(valorModificado);
            }
        });
    }

    public JPanel getPanel(){
        return pnlPrincipal;
    }
}
