import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JuegoNumero {
    private JPanel panelMain;
    private JLabel IntervaloNumero;
    private JTextField txtIntervalo;
    private JTextField txtNumPosible;
    private JButton butVerificar;
    private JButton butComenzar;
    private JTextField txtMensajes;
    private JLabel IntroduceNumero;
    private JLabel TituloJuego;
    private int numeroQueAdivinar =-1;
    private int maxIntervalo;

    public JuegoNumero() {
        butComenzar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoIntroducido = txtIntervalo.getText();
                if (textoIntroducido.matches("[0-9]+")) {
                    maxIntervalo = Integer.parseInt(textoIntroducido);
                    if (maxIntervalo < 2) {
                        txtMensajes.setText("Error. Debe introducir un numero entero mayor de 2");
                    } else {
                        numeroQueAdivinar = (int) ((Math.random() * maxIntervalo)) + 1;
                        butComenzar.setEnabled(false);
                        butVerificar.setEnabled(true);
                        txtNumPosible.setEnabled(true);
                        txtIntervalo.setEnabled(false);
                        txtNumPosible.grabFocus();
                        txtMensajes.setText("");
                    }
                } else {
                    txtMensajes.setText("Error. Debe introducir un numero entero mayor de 2");
                }
            }
        });

        butVerificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoIntroducido = txtNumPosible.getText();
                if (textoIntroducido.matches("[0-9]+")) {
                    int numeroQueVerificar=Integer.parseInt(textoIntroducido);
                    if (numeroQueVerificar<=maxIntervalo) {
                        if (numeroQueAdivinar<numeroQueVerificar){
                            txtNumPosible.setText("");
                            txtNumPosible.grabFocus();
                            txtMensajes.setText("El numero buscado es menor, vuelve a intentarlo.");
                        }
                        else if (numeroQueAdivinar>numeroQueVerificar){
                            txtNumPosible.setText("");
                            txtNumPosible.grabFocus();
                            txtMensajes.setText("El numero buscado es mayor, vuelve a intentarlo.");
                        }
                        else {
                            txtMensajes.setText("¡Enhorabuena! ¡Lo has encontrado!. Era " +
                                                    numeroQueAdivinar+
                                                    "¿Otra partida?");
                            butComenzar.setEnabled(true);
                            butVerificar.setEnabled(false);
                            txtNumPosible.setText("");
                            txtNumPosible.setEnabled(false);
                            txtIntervalo.setText("");
                            txtIntervalo.setEnabled(true);
                            txtIntervalo.grabFocus();
                        }
                    } else {
                        txtMensajes.setText("Error. El numero debe ser menor o igual que " + maxIntervalo);
                    }
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("JuegoNumero");
        frame.setContentPane(new JuegoNumero().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}
