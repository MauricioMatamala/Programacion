import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ApMundo {
    private JPanel panelMain;
    private JLabel lblPaises;
    private JComboBox listaPaises;
    private JButton butBuscar;
    private JTextArea txtAeropuertos;
    private JLabel lblInfo;
    private static Document xmlDoc = null;
    private static ArrayList<String> paises = new ArrayList<String>();
    private static ArrayList<String> lista = new ArrayList<String>();
    static long inicio;
    private String dir = System.getProperty("user.dir");

    public ApMundo() {
        //Para conseguir la lista con todos los paises.
        try {
            File inputFile = new File(dir + File.separator + "aeropuertos.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            // distinct-values(//aeropuerto[@pais]) XPATH 2.0
            NodeList nodeList = doc.getElementsByTagName("aeropuerto");
            for (int n = nodeList.getLength() - 1; n >= 0; n--) {
                Node nodo = nodeList.item(n);
                short nodeType = nodo.getNodeType();
                if (nodeType == Node.ELEMENT_NODE) {
                    String pais = nodo.getAttributes().getNamedItem("pais").getNodeValue().trim();
                    paises.add(pais);
                }
            }
            //Eliminamos los elementos repetidos.
            Set<String> hs = new HashSet<>();
            hs.addAll(paises);
            paises.clear();
            paises.addAll(hs);
            Collections.sort(paises);
            paises.forEach((pais) -> listaPaises.addItem(pais));
            lblPaises.setText("Elija país (" + paises.size() + ") :");
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        //Al pulsar el botón filtra por país seleccionado y muestra los aeropuertos.
        butBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paises.clear();
                txtAeropuertos.setText("");
                String paisSel = listaPaises.getSelectedItem().toString();
                System.out.println(paisSel);
                XPath xPath = XPathFactory.newInstance().newXPath();
                try {
                    File inputFile = new File(dir + File.separator + "aeropuertos.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();
                    XPathExpression expression = xPath.compile("//aeropuerto[@pais='" + paisSel + "']");
                    NodeList nodeList = (NodeList) expression.evaluate(doc, XPathConstants.NODESET);
                    System.out.println("nodos " + nodeList.getLength());
                    for (int n = nodeList.getLength() - 1; n >= 0; n--) {
                        Node nodo = nodeList.item(n);
                        short nodeType = nodo.getNodeType();
                        if (nodeType == Node.ELEMENT_NODE) {
                            paises.add(nodo.getAttributes().getNamedItem("nombreCorto").getNodeValue());
                        }
                    }
                    Collections.sort(paises);
                    paises.forEach((pais) -> txtAeropuertos.append(pais + "\n"));
                    lblInfo.setText("Aeropuertos (" + paises.size() + ")");
                } catch (XPathExpressionException f) {
                    f.printStackTrace();
                } catch (SAXException f) {
                    f.printStackTrace();
                } catch (IOException f) {
                    f.printStackTrace();
                } catch (ParserConfigurationException f) {
                    f.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Aeropuertos por país");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new ApMundo().panelMain);
        frame.setSize(550, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
