package edades;

public class CalculadoraEtapa {
    public String calcular(int edad){
        if (edad > 65)
            return "Feliz pero jodido";
        else if (edad > 49)
            return "Jodido y punto";
        else if (edad > 39)
            return "Viejoven";
        else if (edad > 29)
            return "Joven";
        else if (edad > 13)
            return "Adolescente";
        else
            return "Niño";
    }
}
