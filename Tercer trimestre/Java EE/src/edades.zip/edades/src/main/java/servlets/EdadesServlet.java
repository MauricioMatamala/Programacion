package servlets;

import edades.CalculadoraEtapa;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class EdadesServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int edad = Integer.parseInt(req.getParameter("edad"));
        CalculadoraEtapa calculadoraEtapa = new CalculadoraEtapa();
        String etapa = calculadoraEtapa.calcular(edad);
        req.setAttribute("etapa",etapa);

        RequestDispatcher vista = req.getRequestDispatcher("/edades.jsp");
        vista.forward(req,resp);
    }


}
