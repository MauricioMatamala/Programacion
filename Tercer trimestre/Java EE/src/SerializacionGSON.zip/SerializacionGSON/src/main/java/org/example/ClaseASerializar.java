package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ClaseASerializar {
    int numero;
    String cadena;
    List<String> listaDeCadenas;
    List<ClaseSecundaria> listaDeObjetosSecundarios;
    Map<Integer,Integer> mapaDeNumeros;
    Map<String,ClaseSecundaria> mapaDeObjetosSecundarios;

    public ClaseASerializar(int numero, String cadena) {
        this.numero = numero;
        this.cadena = cadena;
        listaDeCadenas = new ArrayList<>();
        listaDeObjetosSecundarios = new ArrayList<>();
        mapaDeNumeros = new TreeMap<>();
        mapaDeObjetosSecundarios = new TreeMap<>();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCadena() {
        return cadena;
    }

    public void setCadena(String cadena) {
        this.cadena = cadena;
    }

    public void addCadena(String cadena){
        listaDeCadenas.add(cadena);
    }

    public List<String> getCadenas(){
        return listaDeCadenas;
    }

    public void putNumero(Integer clave, Integer valor){
        mapaDeNumeros.put(clave,valor);
    }
    public Map<Integer,Integer> getMapaDeNumeros(){
        return mapaDeNumeros;
    }

    public void addObjetosSecundarios(ClaseSecundaria objeto){
        listaDeObjetosSecundarios.add(objeto);
    }

    public List<ClaseSecundaria> getObjetosSecundarios(){
        return listaDeObjetosSecundarios;
    }

    public void putObjetoSecundario(String clave, ClaseSecundaria objeto){
        mapaDeObjetosSecundarios.put(clave,objeto);
    }

    public Map<String,ClaseSecundaria> getMapaDeObjetosSecundarios(){
        return mapaDeObjetosSecundarios;
    }

    @Override
    public String toString() {
        return "ClaseASerializar{" +
                "numero=" + numero +
                ", cadena='" + cadena + '\'' +
                ", listaDeCadenas=" + listaDeCadenas +
                ", listaDeObjetosSecundarios=" + listaDeObjetosSecundarios +
                ", mapaDeNumeros=" + mapaDeNumeros +
                ", mapaDeObjetosSecundarios=" + mapaDeObjetosSecundarios +
                '}';
    }
}
