package org.example;

import com.google.gson.Gson;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ClaseASerializar objetoJavaAJSON = new ClaseASerializar(1,"aaa");
        objetoJavaAJSON.addCadena("AAA");
        objetoJavaAJSON.addCadena("BBB");
        objetoJavaAJSON.addCadena("CCC");

        objetoJavaAJSON.putNumero(1,1000);
        objetoJavaAJSON.putNumero(2,2000);
        objetoJavaAJSON.putNumero(3,3000);

        objetoJavaAJSON.addObjetosSecundarios(new ClaseSecundaria("os1",1));
        objetoJavaAJSON.addObjetosSecundarios(new ClaseSecundaria("os2",2));
        objetoJavaAJSON.addObjetosSecundarios(new ClaseSecundaria("os3",3));

        objetoJavaAJSON.putObjetoSecundario("OS1",new ClaseSecundaria("OS1",10));
        objetoJavaAJSON.putObjetoSecundario("OS1",new ClaseSecundaria("OS1",20));
        objetoJavaAJSON.putObjetoSecundario("OS1",new ClaseSecundaria("OS1",20));

        Gson gson = new Gson();

        String json = gson.toJson(objetoJavaAJSON);

        ClaseASerializar jsonAObjetoJava = gson.fromJson(json,ClaseASerializar.class);

        System.out.println(json);
        System.out.println(jsonAObjetoJava);

    }
}
