import java.util.Objects;

public class StockProducto {
    private int unidades;
    private int umbral;
    private Producto producto;

   // Código aquí
}
