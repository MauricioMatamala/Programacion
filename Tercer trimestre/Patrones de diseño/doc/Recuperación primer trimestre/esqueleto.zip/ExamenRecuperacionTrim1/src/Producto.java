public class Producto {
    private String nombre;
    private String ref;
    private double precio;

    // Código aquí
}
