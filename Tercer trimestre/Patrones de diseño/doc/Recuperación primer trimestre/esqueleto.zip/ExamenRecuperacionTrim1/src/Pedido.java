public class Pedido {
    private int cantidad;
    private Producto producto;

    // Código aquí
}
