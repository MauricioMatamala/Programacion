import java.util.ArrayList;

public class Almacen {
    private ArrayList<StockProducto> stockProductos;

    // Código aquí
}
