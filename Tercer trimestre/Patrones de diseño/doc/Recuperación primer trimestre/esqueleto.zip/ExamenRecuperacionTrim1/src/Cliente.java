import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private ArrayList<Pedido> pedidos;
 
    // Código aquí
}
