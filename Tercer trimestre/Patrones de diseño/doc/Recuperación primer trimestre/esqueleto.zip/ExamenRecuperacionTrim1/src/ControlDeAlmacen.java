import java.util.ArrayList;

public class ControlDeAlmacen {
    private ArrayList<StockProducto> ordenesDeReposicion;

    // Código aquí
    
}
