package com.politecnicomalaga;

import com.politecnicomalaga.builder.ArbolBuilder;
import com.politecnicomalaga.composite.Contenedor;
import com.politecnicomalaga.composite.Hoja;
import com.politecnicomalaga.composite.Nodo;

import javax.accessibility.AccessibleRole;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Contenedor raiz = new Contenedor(1,1);
        ArbolBuilder builder = new ArbolBuilder(raiz);
        builder.abrirContenedor(2,2)
                    .abrirContenedor(3,3)
                        .addHijo(4,4)
                        .addHijo(5,5)
                    .cerrarContenedor()
                    .addHijo(6,6)
                .cerrarContenedor()
                .abrirContenedor(7,7)
                    .addHijo(8,8)
                    .addHijo(9,9)
                .cerrarContenedor();
        Nodo nodo = (Nodo) builder.getResult();

        System.out.println(nodo.getCoste());
        System.out.println(nodo.toString());
    }
}
