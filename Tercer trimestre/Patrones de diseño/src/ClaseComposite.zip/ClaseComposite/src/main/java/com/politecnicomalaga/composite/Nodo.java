package com.politecnicomalaga.composite;

public interface Nodo {
    public int getId();
    public int getCoste();
    public String toString();
}
