package com.politecnicomalaga.composite;

public class Hoja implements Nodo, Arbol {
    private int id;
    private int coste;
    private Contenedor padre;

    public Hoja(int id, int coste){
        this.id = id;
        this.coste = coste;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public int getCoste() {
        return coste;
    }

    @Override
    public int getTipo() {
        return Arbol.HOJA;
    }

    @Override
    public void setPadre(Contenedor padre) {
        this.padre = padre;
    }

    @Override
    public Contenedor getPadre() {
        return padre;
    }

    @Override
    public String toString() {
        return String.valueOf(id);
    }
}
