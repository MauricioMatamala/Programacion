package com.politecnicomalaga.builder;

import com.politecnicomalaga.composite.Arbol;
import com.politecnicomalaga.composite.Contenedor;
import com.politecnicomalaga.composite.Hoja;
import com.politecnicomalaga.composite.Nodo;

public class ArbolBuilder {
    Arbol nodoArbolActual;

    public ArbolBuilder(Arbol raiz){
        nodoArbolActual = raiz;
    }

    public ArbolBuilder abrirContenedor(int id, int coste){
        Contenedor contenedor = new Contenedor(id,coste);
        if (nodoArbolActual.getTipo() == Arbol.CONTENEDOR) {
            ((Contenedor) nodoArbolActual).addHijo(contenedor);
            nodoArbolActual = contenedor;
        } else throw new IllegalArgumentException("No es un contenedor");
        return this;
    }

    public ArbolBuilder cerrarContenedor(){
        nodoArbolActual = ((Contenedor)nodoArbolActual).getPadre();
        return this;
    }

    public ArbolBuilder addHijo(int id, int coste){
        Hoja hoja = new Hoja(id,coste);
        ((Contenedor)nodoArbolActual).addHijo(hoja);
        return this;
    }

    public Arbol getResult(){
        return nodoArbolActual;
    }

}
