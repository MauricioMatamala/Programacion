package com.politecnicomalaga.composite;

public interface Arbol {
    public final static int HOJA=1;
    public final static int CONTENEDOR=2;

    public int getTipo();
    public void setPadre(Contenedor padre);
    public Contenedor getPadre();
}
