package com.politecnicomalaga.composite;

import java.util.ArrayList;
import java.util.List;

public class Contenedor implements Nodo, Arbol{
    int id;
    int coste;
    List<Arbol> hijos;
    Contenedor padre;

    public Contenedor(int id, int coste){
        hijos = new ArrayList<>();
        this.id = id;
        this.coste = coste;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public int getCoste() {
        int costeTotal = coste;
        for (Arbol hijo : hijos) {
            costeTotal += ((Nodo)hijo).getCoste();
        }
        return costeTotal;
    }


    public void addHijo(Arbol hijo){
        ((Arbol) hijo).setPadre(this);
        hijos.add(hijo);
    }

    public Arbol getHijo(int i){
        return hijos.get(i);
    }

    public List<Arbol> getHijos(){
        return hijos;
    }

    @Override
    public int getTipo() {
        return Arbol.CONTENEDOR;
    }

    @Override
    public void setPadre(Contenedor padre) {
        this.padre = padre;
    }

    @Override
    public Contenedor getPadre() {
        return padre;
    }

    @Override
    public String toString() {
        String resultado = "[" + id + "{";
        for (Arbol hijo : hijos) {
            resultado += hijo.toString() + ",";
        }
        resultado += "}]";
        return resultado;
    }
}
