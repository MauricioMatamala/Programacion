package com.politecnico.ejemplo_factory_method.producto;

public class Barco implements Transporte {

    Envio envio;

    public Barco(){
        envio = new Contenedor();
    }

    @Override
    public String getTipoTransporte() {
        return "Barco";
    }

    @Override
    public Envio getEnvio() {
        return envio;
    }
}
