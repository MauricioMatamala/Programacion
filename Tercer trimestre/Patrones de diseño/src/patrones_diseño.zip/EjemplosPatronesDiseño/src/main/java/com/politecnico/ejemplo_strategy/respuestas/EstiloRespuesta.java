package com.politecnico.ejemplo_strategy.respuestas;

public interface EstiloRespuesta {
    public final static int ESTILO_SIMPLE = 1;
    public final static int ESTILO_GALLEGO = 2;
    public final static int ESTILO_DIRECTO = 3;
    public final static int ESTILO_AMABLE = 4;
    public final static int ESTILO_MUY_GROSERO = 5;
    public final static int ESTILO_GROSERO = 6;

    public String responder();
}
