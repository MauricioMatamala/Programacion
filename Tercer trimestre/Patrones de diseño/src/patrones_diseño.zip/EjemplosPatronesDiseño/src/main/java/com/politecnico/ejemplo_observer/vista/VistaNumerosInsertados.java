package com.politecnico.ejemplo_observer.vista;

import com.politecnico.ejemplo_observer.modelo.NumerosPublisher;

import javax.swing.*;
import java.util.List;

public class VistaNumerosInsertados implements NumerosSuscriber{
    private JList lstNumeros;
    private JPanel pnlNumerosInsertados;
    private DefaultListModel<Integer> numerosAdapter;

    @Override
    public void update(List<Integer> listaNumeros) {
        numerosAdapter.addElement(listaNumeros.get(listaNumeros.size()-1));
    }

    public JPanel getPanel(){
        return pnlNumerosInsertados;
    }

    private void createUIComponents() {
         lstNumeros = new JList();
         numerosAdapter = new DefaultListModel<>();
         lstNumeros.setModel(numerosAdapter);
    }
}
