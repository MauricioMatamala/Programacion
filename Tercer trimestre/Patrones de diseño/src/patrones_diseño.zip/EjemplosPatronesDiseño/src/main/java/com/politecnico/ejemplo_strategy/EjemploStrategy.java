package com.politecnico.ejemplo_strategy;

import com.politecnico.ejemplo_strategy.factory_estilo_respuesta.EstiloRespuestaFactory;
import com.politecnico.ejemplo_strategy.respuestas.EstiloRespuesta;
import com.politecnico.ejemplo_strategy.respuestas.Respuesta;

import java.util.Scanner;

public class EjemploStrategy {
    static Scanner lectorTeclado = new Scanner(System.in).useDelimiter("\n");
    public static void main(String[] args) {
        System.out.println("\n[CONSERJE] - Eh amigo, ¿Tienes un gato muerto ahí dentro?");

        System.out.println("-------------------------------------");
        System.out.println("Elige una estrategia de respuesta:");
        System.out.print( "1. Simple\n" +
                            "2. Gallego\n" +
                            "3. Directo\n" +
                            "4. Amable\n" +
                            "5. Muy grosero\n" +
                            "6. Grosero\n" +
                            "Opción:");
        int opcion = lectorTeclado.nextInt();
        System.out.println("------------------------------------");

        EstiloRespuesta estiloRespuesta = EstiloRespuestaFactory.getEstiloRespuesta(opcion);
        Respuesta generadorRespuesta = new Respuesta();
        generadorRespuesta.setEstiloRespuesta(estiloRespuesta);
        System.out.println("\n[T101] - " + generadorRespuesta.getRespuesta());
    }
}
