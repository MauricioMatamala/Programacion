package com.politecnico.ejemplo_observer.vista;

import com.politecnico.ejemplo_observer.modelo.NumerosPublisher;

import java.util.List;

public interface NumerosSuscriber {
    public void update(List<Integer> listaNumeros);
}
