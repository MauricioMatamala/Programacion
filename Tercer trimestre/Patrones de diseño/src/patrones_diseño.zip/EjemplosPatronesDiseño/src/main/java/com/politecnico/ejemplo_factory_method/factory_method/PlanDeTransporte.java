package com.politecnico.ejemplo_factory_method.factory_method;

import com.politecnico.ejemplo_factory_method.producto.Transporte;

public interface PlanDeTransporte {
    public abstract Transporte crearTransporte();
}
