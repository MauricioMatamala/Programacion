package com.politecnico.ejemplo_abstract_factory.abstract_factory;

import com.politecnico.ejemplo_abstract_factory.producto.*;

public class AlmuerzoFactory implements ComidaFactory {
    @Override
    public Comida crearComida() {
        return new Hamburgesa();
    }

    @Override
    public Bebida crearBebida() {
        return new Refresco();
    }

    @Override
    public Salsa crearSalsa() {
        return new Ketchup();
    }
}
