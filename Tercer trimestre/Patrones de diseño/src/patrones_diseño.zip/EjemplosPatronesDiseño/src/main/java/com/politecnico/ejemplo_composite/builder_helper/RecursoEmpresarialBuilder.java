package com.politecnico.ejemplo_composite.builder_helper;

import com.politecnico.ejemplo_composite.composite.Empleado;
import com.politecnico.ejemplo_composite.composite.RecursoEmpresarial;
import com.politecnico.ejemplo_composite.composite.UnidadOrganizativa;

public class RecursoEmpresarialBuilder {
    private RecursoEmpresarialBuilder builderPadre;
    private UnidadOrganizativa unidadOrganizativa;

    public RecursoEmpresarialBuilder(String nombreUnidadOrganizativa){
        this.unidadOrganizativa = new UnidadOrganizativa(nombreUnidadOrganizativa);
        builderPadre = null;
    }

    public RecursoEmpresarialBuilder(UnidadOrganizativa unidadOrganizativa, RecursoEmpresarialBuilder builderPadre){
        this.unidadOrganizativa = unidadOrganizativa;
        this.builderPadre = builderPadre;
    }

    public RecursoEmpresarialBuilder iniciarUnidadOrganizativa(String nombreNuevaUO){
        UnidadOrganizativa nuevaUO = new UnidadOrganizativa(nombreNuevaUO);
        this.unidadOrganizativa.add(nuevaUO);
        return new RecursoEmpresarialBuilder(nuevaUO,this);
    }

    public RecursoEmpresarialBuilder finalizarUnidadOrganizativa(){
        return builderPadre;
    }

    public RecursoEmpresarialBuilder addEmpleado(String nombre, double sueldo){
        unidadOrganizativa.add(new Empleado(nombre,sueldo));
        return this;
    }

    public RecursoEmpresarial getResultado(){
        return unidadOrganizativa;
    }
}
