package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloGrosero implements EstiloRespuesta{
    @Override
    public String responder() {
        return "¡Que te den!";
    }
}
