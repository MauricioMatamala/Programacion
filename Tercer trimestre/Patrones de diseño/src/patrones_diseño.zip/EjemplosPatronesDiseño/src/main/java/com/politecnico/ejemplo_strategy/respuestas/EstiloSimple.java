package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloSimple implements EstiloRespuesta{
    @Override
    public String responder() {
        return "No";
    }
}
