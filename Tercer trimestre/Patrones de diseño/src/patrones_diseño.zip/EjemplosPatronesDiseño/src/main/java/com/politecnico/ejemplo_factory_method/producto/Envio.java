package com.politecnico.ejemplo_factory_method.producto;

public interface Envio {
    public String getTipo();
}
