package com.politecnico.ejemplo_observer.modelo;

import com.politecnico.ejemplo_observer.vista.NumerosSuscriber;

import java.util.List;

public interface NumerosPublisher {
    public void suscribir(NumerosSuscriber suscriber);
    public void anularSuscripcion(NumerosSuscriber suscriber);
    public void notificarASuscriptores();
}
