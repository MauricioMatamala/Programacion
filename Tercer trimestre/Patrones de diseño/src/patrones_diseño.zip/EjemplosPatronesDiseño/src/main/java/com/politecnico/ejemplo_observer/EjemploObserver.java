package com.politecnico.ejemplo_observer;

import com.politecnico.ejemplo_observer.modelo.Numeros;
import com.politecnico.ejemplo_observer.vista.VistaInsercionNumeros;
import com.politecnico.ejemplo_observer.vista.VistaNumerosInsertados;

import javax.swing.*;
import java.awt.*;

public class EjemploObserver {

    public static void main(String[] args) {
        Numeros numeros = new Numeros();
        VistaNumerosInsertados vistaNumerosInsertados = new VistaNumerosInsertados();
        VistaInsercionNumeros vistaInsercionNumeros = new VistaInsercionNumeros(numeros);
        numeros.suscribir(vistaNumerosInsertados);

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        int height = toolkit.getScreenSize().height;
        int width = toolkit.getScreenSize().width;

        JFrame frame1 = new JFrame("Insertar números");
        frame1.setContentPane(vistaInsercionNumeros.getPanel());
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.pack();
        frame1.setSize((width-100)/2,height/2);
        frame1.setLocation(0,height/4);
        frame1.setVisible(true);

        JFrame frame2 = new JFrame("Números insertados");
        frame2.setContentPane(vistaNumerosInsertados.getPanel());
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.pack();
        frame2.setSize((width-100)/2,height/2);
        frame2.setLocation(width-(frame2.getWidth()),frame1.getY());
        frame2.setVisible(true);
    }
}
