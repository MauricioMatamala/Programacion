package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloGallego implements EstiloRespuesta{
    @Override
    public String responder() {
        return "¿O qué?";
    }
}
