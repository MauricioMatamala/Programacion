package com.politecnico.ejemplo_abstract_factory;

import com.politecnico.ejemplo_abstract_factory.abstract_factory.AlmuerzoFactory;
import com.politecnico.ejemplo_abstract_factory.abstract_factory.ComidaFactory;
import com.politecnico.ejemplo_abstract_factory.abstract_factory.DesayunoFactory;
import com.politecnico.ejemplo_abstract_factory.abstract_factory.MeriendaFactory;
import com.politecnico.ejemplo_abstract_factory.producto.Bebida;
import com.politecnico.ejemplo_abstract_factory.producto.Comida;
import com.politecnico.ejemplo_abstract_factory.producto.MomentoDeComida;
import com.politecnico.ejemplo_abstract_factory.producto.Salsa;

/*
Merienda: Gofre         / Sirope de fresa   / Batido de vainilla
Almuerzo: Hamburguesa   / Ketchup           / Refresco
Desayuno: Tostada       / Aceite de oliva   / Café
 */

public class EjemploAbstractFactory {
    public static ComidaFactory comidaFactory;
    public final static MomentoDeComida momentoDeComida = MomentoDeComida.DESAYUNO;

    public static void main(String[] args) {
        inicializar();
        Comida comida = comidaFactory.crearComida();
        Bebida bebida = comidaFactory.crearBebida();
        Salsa salsa = comidaFactory.crearSalsa();

        System.out.println("Para comer, se ha pedido " + comida.getNombreComida() + " con salsa de " + salsa.getNombreSalsa());
        System.out.println("Para beber, se ha pedido " + bebida.getNombreBebida());
    }

    private static void inicializar(){
        // El código de este método se puede ubicar en otra parte, pero debe ser ejecutado una vez,
        // para garantizar durante toda la ejecución la compatibilidad entre los productos creados.

        switch (momentoDeComida){
            case DESAYUNO:
                comidaFactory = new DesayunoFactory();
                break;
            case ALMUERZO:
                comidaFactory = new AlmuerzoFactory();
                break;
            case MERIENDA:
                comidaFactory = new MeriendaFactory();
                break;
            default:
                throw new IllegalArgumentException("No existe esa hora de la comida");
        }
    }
}
