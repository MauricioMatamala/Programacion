package com.politecnicomalaga.vista;

import com.politecnicomalaga.controlador.ControladorTemperaturas;
import com.politecnicomalaga.modelo.SensorSuscriber;
import com.politecnicomalaga.modelo.SensorTemperatura;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class VistaPrincipal implements SensorSuscriber {
    private JList lstLecturas;
    private JButton btnTemperaturasCriticas;
    private JButton btnTemperaturasPromedio;
    private JPanel pnlMain;
    private ControladorTemperaturas controlador;
    private DefaultListModel<Integer> modeloLista;

    public VistaPrincipal(ControladorTemperaturas controlador){
        this.controlador = controlador;
        btnTemperaturasCriticas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controlador.mostrarVistaTemperaturasCriticas();
            }
        });

        btnTemperaturasPromedio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controlador.mostrarVistaPromedioTemperaturas();
            }
        });
    }

    private void createUIComponents() {
        lstLecturas = new JList();
        modeloLista = new DefaultListModel<>();
        lstLecturas.setModel(modeloLista);
    }


    @Override
    public void update(SensorTemperatura sensor) throws IOException {
        modeloLista.addElement(sensor.getUltimaLectura());
    }


    public Container getPanel() {
        return pnlMain;
    }
}
