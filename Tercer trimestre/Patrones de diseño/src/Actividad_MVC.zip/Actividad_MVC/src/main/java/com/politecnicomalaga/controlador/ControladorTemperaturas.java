package com.politecnicomalaga.controlador;

import com.politecnicomalaga.modelo.SensorTemperatura;
import com.politecnicomalaga.vista.VistaPrincipal;
import com.politecnicomalaga.vista.VistaTemperaturaPromedio;
import com.politecnicomalaga.vista.VistaTemperaturasCriticas;

import javax.swing.*;
import java.awt.*;

public class ControladorTemperaturas {
    private SensorTemperatura sensorTemperatura;
    private VistaPrincipal vistaPrincipal;
    private VistaTemperaturasCriticas vistaTemperaturasCriticas;
    private VistaTemperaturaPromedio vistaTemperaturasPromedio;
    JFrame marcoPrincipal;
    JFrame marcoTemperaturasCriticas;
    JFrame marcoTemperaturaPromedio;
    public ControladorTemperaturas(SensorTemperatura sensorTemperatura){
        this.sensorTemperatura = sensorTemperatura;
        vistaPrincipal = new VistaPrincipal(this);
        vistaTemperaturasCriticas = new VistaTemperaturasCriticas(this);
        vistaTemperaturasPromedio = new VistaTemperaturaPromedio(this);

        sensorTemperatura.suscribe(vistaPrincipal);
        sensorTemperatura.suscribe(vistaTemperaturasCriticas);
        sensorTemperatura.suscribe(vistaTemperaturasPromedio);

        marcoPrincipal = new JFrame("Temperaturas");
        marcoPrincipal.setContentPane(vistaPrincipal.getPanel());
        marcoPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marcoPrincipal.pack();
        marcoPrincipal.setLocationRelativeTo(null);
        marcoPrincipal.setVisible(true);

        marcoTemperaturasCriticas = new JFrame("Temperaturas críticas");
        marcoTemperaturasCriticas.setContentPane(vistaTemperaturasCriticas.getPanel());
        marcoTemperaturasCriticas.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        marcoTemperaturasCriticas.pack();
        marcoTemperaturasCriticas.setLocationRelativeTo(null);
        marcoTemperaturasCriticas.setVisible(false);

        marcoTemperaturaPromedio = new JFrame("Promedio de temperaturas");
        marcoTemperaturaPromedio.setContentPane(vistaTemperaturasPromedio.getPanel());
        marcoTemperaturaPromedio.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        marcoTemperaturaPromedio.setPreferredSize(new Dimension(300, -1));
        marcoTemperaturaPromedio.pack();
        marcoTemperaturaPromedio.setLocationRelativeTo(null);
        marcoTemperaturaPromedio.setVisible(false);
    }

    public void mostrarVistaTemperaturasCriticas(){
        marcoTemperaturasCriticas.setVisible(true);
    }

    public void mostrarVistaPromedioTemperaturas(){
        marcoTemperaturaPromedio.setVisible(true);
    }
}
