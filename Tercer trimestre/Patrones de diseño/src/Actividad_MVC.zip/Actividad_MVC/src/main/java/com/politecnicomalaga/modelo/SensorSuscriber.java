package com.politecnicomalaga.modelo;

import java.io.IOException;

public interface SensorSuscriber {
    public void update(SensorTemperatura sensor) throws IOException;
}
