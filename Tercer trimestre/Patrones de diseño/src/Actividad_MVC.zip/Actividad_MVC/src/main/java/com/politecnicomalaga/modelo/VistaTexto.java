package com.politecnicomalaga.modelo;

import java.io.IOException;
import java.util.logging.*;

public class VistaTexto implements SensorSuscriber{
    @Override
    public void update(SensorTemperatura sensorTemperatura) throws IOException {
        System.out.println("----------------------------------");
        System.out.println("Nueva lectura: " + sensorTemperatura.getUltimaLectura());
        System.out.println("Promedo:" +  sensorTemperatura.getPromedio());
        System.out.println("Temperaturas críticas: " + sensorTemperatura.getTemperaturasCriticas());
    }
}
