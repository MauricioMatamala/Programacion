package com.politecnicomalaga;

import com.politecnicomalaga.controlador.ControladorTemperaturas;
import com.politecnicomalaga.modelo.SensorTemperatura;
import com.politecnicomalaga.modelo.VistaTexto;

import java.util.Timer;

public class App 
{
    public static void main( String[] args )
    {
        Timer temporizador = new Timer();
        SensorTemperatura sensor = new SensorTemperatura();
        temporizador.schedule(sensor,0,5000);
        ControladorTemperaturas controladorTemperaturas = new ControladorTemperaturas(sensor);
        sensor.suscribe(new VistaTexto());
    }
}
