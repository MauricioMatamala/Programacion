package com.politecnicomalaga.vista;

import com.politecnicomalaga.controlador.ControladorTemperaturas;
import com.politecnicomalaga.modelo.SensorSuscriber;
import com.politecnicomalaga.modelo.SensorTemperatura;


import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class VistaTemperaturaPromedio implements SensorSuscriber {
    private JPanel pnlMain;
    private JLabel lblTemperatura;
    private ControladorTemperaturas controladorTemperaturas;

    public VistaTemperaturaPromedio(ControladorTemperaturas controladorTemperaturas) {
        this.controladorTemperaturas = controladorTemperaturas;
    }

    @Override
    public void update(SensorTemperatura sensorTemperatura) throws IOException {
        double promedio = sensorTemperatura.getPromedio();
        lblTemperatura.setText(String.format("%.2f",promedio) + " Cº");
    }


    public Container getPanel() {
        return pnlMain;
    }
}
