package com.politecnicomalaga.modelo;

import java.io.IOException;

public interface SensorPublisher {
    public void suscribe(SensorSuscriber suscriber);
    public void notifySuscribers() throws IOException;
}
