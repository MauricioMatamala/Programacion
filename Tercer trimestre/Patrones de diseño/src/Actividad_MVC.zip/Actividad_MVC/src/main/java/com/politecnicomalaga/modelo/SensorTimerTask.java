package com.politecnicomalaga.modelo;

import java.io.IOException;
import java.util.Random;
import java.util.TimerTask;

// PUEDES IGNORAR ESTA CLASE

public abstract class SensorTimerTask extends TimerTask {

    Random aleatorio;

    public SensorTimerTask(){
        aleatorio = new Random();
    }

    public abstract void nuevaLectura() throws IOException;

    @Override
    public void run() {
        if (hayLectura()) {
            try {
                nuevaLectura();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean hayLectura(){
        return aleatorio.nextBoolean();
    }
}
