package com.politecnicomalaga.modelo;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SensorTemperatura extends SensorTimerTask implements SensorPublisher{
    public final static int UMBRAL_MAXIMO = 160;
    public final static int UMBRAL_MINIMO = 80;
    private int sensor;
    private ArrayList<Integer> lecturasTemperatura;
    private ArrayList<Integer> temperaturasCriticas;
    private double promedio;
    private Random aleatorio;
    private Instant inicio;
    private List<SensorSuscriber> suscribers = new ArrayList<>();

    public SensorTemperatura(){
        aleatorio = new Random();
        inicio = Instant.now();
        lecturasTemperatura = new ArrayList<>();
        temperaturasCriticas = new ArrayList<>();
    }

    public void nuevaLectura() throws IOException {
        sensor = aleatorio.ints(40, 200).limit(1).findFirst().getAsInt();
        Instant ahora = Instant.now();
        Duration period = Duration.between(inicio,ahora);
        lecturasTemperatura.add(sensor);
        if (esTemperaturaCritica(sensor)){
            temperaturasCriticas.add(sensor);
        }
        promedio = calcularPromedio();
        notifySuscribers();
    }

    private boolean esTemperaturaCritica(int sensor) {
        return ((sensor < UMBRAL_MINIMO) || (sensor > UMBRAL_MAXIMO));
    }

    private double calcularPromedio(){
        double total = 0;
        for (Integer lectura : lecturasTemperatura) {
            total += lectura;
        }
        return total/lecturasTemperatura.size();
    }

    public int getUltimaLectura(){
        return sensor;
    }

    public double getPromedio(){
        return promedio;
    }

    public List<Integer> getTemperaturasCriticas(){
        return temperaturasCriticas;
    }

    @Override
    public void suscribe(SensorSuscriber suscriber) {
        suscribers.add(suscriber);
    }

    @Override
    public void notifySuscribers() throws IOException {
        for (SensorSuscriber suscriber : suscribers) {
            suscriber.update(this);
        }
    }
}

