package com.politecnicomalaga.vista;

import com.politecnicomalaga.controlador.ControladorTemperaturas;
import com.politecnicomalaga.modelo.SensorSuscriber;
import com.politecnicomalaga.modelo.SensorTemperatura;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class VistaTemperaturasCriticas implements SensorSuscriber {
    private JList lstTemperaturaPromedio;
    private JPanel pnlMain;
    private ControladorTemperaturas controladorTemperaturas;
    private DefaultListModel<Integer> modeloLista;

    public VistaTemperaturasCriticas(ControladorTemperaturas controladorTemperaturas) {
        this.controladorTemperaturas = controladorTemperaturas;
    }

    @Override
    public void update(SensorTemperatura sensorTemperatura) throws IOException {
        List<Integer> temperaturasCriticas =  sensorTemperatura.getTemperaturasCriticas();
        modeloLista.clear();
        for (Integer temperaturaCritica : temperaturasCriticas) {
            modeloLista.addElement(temperaturaCritica);
        }
    }

    private void createUIComponents() {
        lstTemperaturaPromedio = new JList();
        modeloLista = new DefaultListModel<Integer>();
        lstTemperaturaPromedio.setModel(modeloLista);
    }


    public Container getPanel() {
        return pnlMain;
    }
}
