package com.politecnico.ejemplo_mvc.modelo;

public interface NumerosPublisher {
    public void suscribir(NumerosSuscriber suscriber);
    public void anularSuscripcion(NumerosSuscriber suscriber);
    public void notificarASuscriptores();
}
