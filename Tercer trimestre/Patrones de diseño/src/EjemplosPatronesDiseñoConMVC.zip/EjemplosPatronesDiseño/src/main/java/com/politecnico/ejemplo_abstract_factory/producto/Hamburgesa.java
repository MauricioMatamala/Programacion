package com.politecnico.ejemplo_abstract_factory.producto;

public class Hamburgesa implements Comida {
    @Override
    public String getNombreComida() {
        return "hamburguesa";
    }
}
