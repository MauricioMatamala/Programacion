package com.politecnico.ejemplo_strategy.respuestas;

public class Respuesta {
    private EstiloRespuesta estiloRespuesta;

    public void setEstiloRespuesta(EstiloRespuesta estiloRespuesta){
        this.estiloRespuesta = estiloRespuesta;
    }

    public String getRespuesta(){
        return estiloRespuesta.responder();
    }
}
