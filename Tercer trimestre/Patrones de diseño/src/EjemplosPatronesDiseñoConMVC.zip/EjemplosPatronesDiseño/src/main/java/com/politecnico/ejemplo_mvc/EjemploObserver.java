package com.politecnico.ejemplo_mvc;

import com.politecnico.ejemplo_mvc.modelo.Numeros;
import com.politecnico.ejemplo_mvc.vista.NumerosController;

public class EjemploObserver {

    public static void main(String[] args) {
        Numeros numeros = new Numeros();
        NumerosController numerosController = new NumerosController(numeros);
    }
}
