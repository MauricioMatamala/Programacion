package com.politecnico.ejemplo_composite.composite;

import java.util.ArrayList;
import java.util.List;

public class UnidadOrganizativa implements RecursoEmpresarial {
    private String nombre;
    private List<RecursoEmpresarial> listaRecursos;

    @Override
    public String getNombre() {
        return nombre;
    }

    public UnidadOrganizativa(String nombre) {
        this.nombre = nombre;
        listaRecursos = new ArrayList<>();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<RecursoEmpresarial> getListaRecursos() {
        return listaRecursos;
    }

    public void setListaRecursos(List<RecursoEmpresarial> listaRecursos) {
        this.listaRecursos = listaRecursos;
    }

    @Override
    public double calcularCosteSueldo() {
        double costeSueldo = 0;
        for (RecursoEmpresarial recurso : listaRecursos) {
            costeSueldo += recurso.calcularCosteSueldo();
        }
        return costeSueldo;
    }

    public void add(RecursoEmpresarial recurso){
        listaRecursos.add(recurso);
    }

    public void remove(RecursoEmpresarial recurso){
        listaRecursos.remove(recurso);
    }

    public List<RecursoEmpresarial> getChildren(){
        return listaRecursos;
    }

    public RecursoEmpresarial getRecursoEmpresarialPorNombre(String nombre){
        if (this.nombre == nombre)
            return this;
        else for (RecursoEmpresarial recurso : listaRecursos) {
            if (recurso.getTipo() == RecursoEmpresarial.UNIDAD_ORGANIZATIVA){
                UnidadOrganizativa uo = (UnidadOrganizativa)recurso;
                RecursoEmpresarial subRecurso = ((UnidadOrganizativa) recurso).getRecursoEmpresarialPorNombre(nombre);
                if ((subRecurso != null) && (subRecurso.getNombre() == nombre))
                    return subRecurso;
            } else if (recurso.getTipo() == RecursoEmpresarial.EMPLEADO)
                if (recurso.getNombre() == nombre)
                    return recurso;
        }
        return null;
    }

    public String toString(){
        String resultado = nombre + " [";
        for (int i=0; i<listaRecursos.size()-1; i++) {
            resultado += listaRecursos.get(i).toString() + ",";
        }
        if (listaRecursos.size()>0)
            resultado += listaRecursos.get(listaRecursos.size()-1);
        resultado += "]";
        return resultado;
    }

    @Override
    public int getTipo() {
        return RecursoEmpresarial.UNIDAD_ORGANIZATIVA;
    }
}
