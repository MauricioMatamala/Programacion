package com.politecnico.ejemplo_mvc.vista;

import com.politecnico.ejemplo_mvc.modelo.NumerosSuscriber;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VistaNumerosInsertados implements NumerosSuscriber {
    private JList lstNumeros;
    private JPanel pnlNumerosInsertados;
    private JButton btnInsertar;
    private DefaultListModel<Integer> numerosAdapter;
    private NumerosController numerosController;

    public VistaNumerosInsertados(NumerosController numerosController){
        this.numerosController = numerosController;

        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mostrarVistaInsercion();
            }
        });
    }

    private void mostrarVistaInsercion(){
        numerosController.mostrarVistaInsercion();
    }

    // La vista es actualizada por el modelo mediante
    // el patrón observer.
    @Override
    public void update(List<Integer> listaNumeros) {
        numerosAdapter.addElement(listaNumeros.get(listaNumeros.size()-1));
    }

    public JPanel getPanel(){
        return pnlNumerosInsertados;
    }

    private void createUIComponents() {
         lstNumeros = new JList();
         numerosAdapter = new DefaultListModel<>();
         lstNumeros.setModel(numerosAdapter);
    }
}
