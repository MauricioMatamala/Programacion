package com.politecnico.ejemplo_mvc.modelo;

import java.util.List;

public interface NumerosSuscriber {
    public void update(List<Integer> listaNumeros);
}
