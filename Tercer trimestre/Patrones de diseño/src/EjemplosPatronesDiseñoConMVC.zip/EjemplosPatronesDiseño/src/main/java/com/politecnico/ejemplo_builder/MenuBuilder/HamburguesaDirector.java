package com.politecnico.ejemplo_builder.MenuBuilder;

import com.politecnico.ejemplo_builder.Producto.Hamburguesa;

public class HamburguesaDirector {
    private HamburguesaBuilder builder;

    public HamburguesaDirector(HamburguesaBuilder builder){
        this.builder = builder;
    }

    public Hamburguesa servirHamburguesaNormal(){
        return builder.setTipo(TipoHamburguesa.NORMAL).getResultado();
    }

    public Hamburguesa servirHamburguesaConQueso(){
        return builder.addQueso()
                      .setTipo(TipoHamburguesa.CON_QUESO)
                      .getResultado();
    }

    public Hamburguesa servirHamburquesaCompleta(){
        return builder.addQueso()
                      .addLechuga()
                      .addTomate()
                      .setTipo(TipoHamburguesa.COMPLETA)
                      .getResultado();
    }

    public Hamburguesa servirHamburguesaDoble(){
        return builder.setDoble()
                      .setTipo(TipoHamburguesa.DOBLE)
                      .getResultado();
    }

    public Hamburguesa servirHamburguesaDobleCompleta(){
        return builder.setDoble()
                      .addQueso()
                      .addLechuga()
                      .addTomate()
                      .setTipo(TipoHamburguesa.DOBLE_COMPLETA)
                      .getResultado();
    }

    public Hamburguesa servirHamburguesaCheeseBacon(){
        return builder.addQueso()
                      .addBacon()
                      .setTipo(TipoHamburguesa.CHEESE_BACON)
                      .getResultado();
    }

    public Hamburguesa servirHamburguesaHercules(){
        return builder.setDoble()
                      .addQueso()
                      .addTomate()
                      .addBacon()
                      .addHuevo()
                      .addSalsaChile()
                      .setTipo(TipoHamburguesa.HERCULES)
                      .getResultado();
    }

    public Hamburguesa servirHamburguesaGodzilla(){
        return builder.setDoble()
                      .addTomate()
                      .addLechuga()
                      .addCebolla()
                      .addPepinillo()
                      .addBacon()
                      .addBacon()
                      .addSalsaChile()
                      .setTipo(TipoHamburguesa.GODZILLA)
                      .getResultado();
    }
}
