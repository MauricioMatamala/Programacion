package com.politecnico.ejemplo_mvc.modelo;

import java.util.ArrayList;
import java.util.List;

public class Numeros implements NumerosPublisher {
    private List<Integer> listaNumeros;
    private List<NumerosSuscriber> subscribers;

    public Numeros(){
        listaNumeros = new ArrayList<Integer>();
        subscribers = new ArrayList<NumerosSuscriber>();
    }

    @Override
    public void suscribir(NumerosSuscriber suscriber) {
        subscribers.add(suscriber);
    }

    @Override
    public void anularSuscripcion(NumerosSuscriber suscriber) {
        subscribers.remove(suscriber);
    }

    @Override
    public void notificarASuscriptores() {
        for (NumerosSuscriber subscriber : subscribers)
            subscriber.update(listaNumeros);
    }

    public void addNumero(int numero){
        listaNumeros.add(numero);
        notificarASuscriptores();
    }

    public List<Integer> getNumeros(){
        return listaNumeros;
    }
}
