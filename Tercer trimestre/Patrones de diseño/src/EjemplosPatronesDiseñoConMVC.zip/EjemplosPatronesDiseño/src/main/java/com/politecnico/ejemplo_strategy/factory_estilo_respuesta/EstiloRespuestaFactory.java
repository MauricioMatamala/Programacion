package com.politecnico.ejemplo_strategy.factory_estilo_respuesta;

import com.politecnico.ejemplo_strategy.respuestas.*;

public class EstiloRespuestaFactory {
    public static EstiloRespuesta getEstiloRespuesta(int estilo){
        switch (estilo){
            case EstiloRespuesta.ESTILO_SIMPLE:
                return new EstiloSimple();
            case EstiloRespuesta.ESTILO_GALLEGO:
                return new EstiloGallego();
            case EstiloRespuesta.ESTILO_DIRECTO:
                return new EstiloDirecto();
            case EstiloRespuesta.ESTILO_AMABLE:
                return new EstiloAmable();
            case EstiloRespuesta.ESTILO_MUY_GROSERO:
                return new EstiloMuyGrosero();
            case EstiloRespuesta.ESTILO_GROSERO:
                return new EstiloGrosero();
            default:
                return new EstiloDirecto();

        }
    }
}
