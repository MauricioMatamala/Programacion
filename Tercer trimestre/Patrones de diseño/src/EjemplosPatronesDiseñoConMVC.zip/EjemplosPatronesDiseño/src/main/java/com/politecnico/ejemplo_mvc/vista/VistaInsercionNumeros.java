package com.politecnico.ejemplo_mvc.vista;

import com.politecnico.ejemplo_mvc.modelo.Numeros;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaInsercionNumeros {
    private JPanel pnlInsertarNumeros;
    private JButton btnInsertarNumero;
    private JSpinner spnNumero;
    private Numeros numeros;
    private NumerosController numerosController;

    public VistaInsercionNumeros(Numeros numeros, NumerosController numerosController){
        this.numerosController = numerosController;
        this.numeros = numeros;
        btnInsertarNumero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                addNumero((Integer)spnNumero.getValue());
                spnNumero.setValue(0);
            }
        });
    }

    private void addNumero(int numero){
        numerosController.insertarNumero(numero);
    }

    public JPanel getPanel(){
        return pnlInsertarNumeros;
    }
}
