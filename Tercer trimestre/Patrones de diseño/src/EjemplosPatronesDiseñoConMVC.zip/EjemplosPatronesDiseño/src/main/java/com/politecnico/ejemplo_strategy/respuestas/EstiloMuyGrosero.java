package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloMuyGrosero implements EstiloRespuesta {
    @Override
    public String responder() {
        return "¡Que te den, imbécil!";
    }
}
