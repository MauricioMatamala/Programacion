package com.politecnico.ejemplo_abstract_factory.abstract_factory;

import com.politecnico.ejemplo_abstract_factory.producto.*;

public class MeriendaFactory implements ComidaFactory {
    @Override
    public Comida crearComida() {
        return new Gofre();
    }

    @Override
    public Bebida crearBebida() {
        return new BatidoVainilla();
    }

    @Override
    public Salsa crearSalsa() {
        return new SiropeFresa();
    }
}
