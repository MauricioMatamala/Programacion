package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloDirecto implements EstiloRespuesta{
    @Override
    public String responder() {
        return "Lárgate";
    }
}
