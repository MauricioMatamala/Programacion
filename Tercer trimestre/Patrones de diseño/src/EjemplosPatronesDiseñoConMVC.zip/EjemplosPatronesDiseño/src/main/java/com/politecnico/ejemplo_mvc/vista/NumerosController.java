package com.politecnico.ejemplo_mvc.vista;

import com.politecnico.ejemplo_mvc.modelo.Numeros;

import javax.swing.*;

public class NumerosController {
    VistaNumerosInsertados vistaNumerosInsertados;
    VistaInsercionNumeros vistaInsercionNumeros;
    Numeros numeros;
    JFrame frameInsertarNumeros;
    JFrame frameNumerosInsertados;

    public NumerosController(Numeros numeros){
        this.numeros = numeros;
        VistaNumerosInsertados vistaNumerosInsertados = new VistaNumerosInsertados(this);
        VistaInsercionNumeros vistaInsercionNumeros = new VistaInsercionNumeros(numeros,this);

        // El controlador suscribe a la vista en el modelo
        // La vista será actualizada sin saber quién lo hace
        // por medio del método update
        numeros.suscribir(vistaNumerosInsertados);

        // El controlador puede crear las vistas y definir sus detalles,
        // aunque no tiene por qué ser así. Esto se puede hacer en otra
        // clase que construya esta relación (cuando ésta está sujeta a cambios)

        frameInsertarNumeros = new JFrame("Insertar números");
        frameInsertarNumeros.setContentPane(vistaInsercionNumeros.getPanel());
        frameInsertarNumeros.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameInsertarNumeros.pack();
        frameInsertarNumeros.setLocationRelativeTo(null);//0,height/4);
        frameInsertarNumeros.setVisible(true);

        frameNumerosInsertados = new JFrame("Números insertados");
        frameNumerosInsertados.setContentPane(vistaNumerosInsertados.getPanel());
        frameNumerosInsertados.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameNumerosInsertados.pack();
        frameNumerosInsertados.setLocationRelativeTo(null);
        frameNumerosInsertados.setVisible(false);
    }

    /*---------------------------------------------------------------
    Salvo para cosas excepcionales, es el controlador quien interactúa
    con el modelo
     */
    public void insertarNumero(int numero){
        numeros.addNumero(numero);
        frameInsertarNumeros.setVisible(false);
        frameNumerosInsertados.setVisible(true);
    }

    /* ---------------------------------------------------------------
    El controlador maneja los cambios generales en las vistas:
     - Qué vista debe verse
     - Si hay alguna parte que debe quedar oculta
     - Elementos que se activan/desactivan
     - Etc.
    */
    public void mostrarVistaInsercion() {
        frameInsertarNumeros.setVisible(true);
        frameNumerosInsertados.setVisible(false);
    }
}
