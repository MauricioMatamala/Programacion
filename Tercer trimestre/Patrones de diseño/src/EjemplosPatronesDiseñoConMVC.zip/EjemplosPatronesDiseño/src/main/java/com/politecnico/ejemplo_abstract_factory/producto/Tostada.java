package com.politecnico.ejemplo_abstract_factory.producto;

public class Tostada implements Comida {
    @Override
    public String getNombreComida() {
        return "tostada";
    }
}
