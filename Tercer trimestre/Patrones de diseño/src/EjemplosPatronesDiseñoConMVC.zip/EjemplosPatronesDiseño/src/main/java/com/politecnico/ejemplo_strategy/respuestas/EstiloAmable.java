package com.politecnico.ejemplo_strategy.respuestas;

public class EstiloAmable implements EstiloRespuesta {
    @Override
    public String responder() {
        return "Vuelva después, por favor.";
    }
}
