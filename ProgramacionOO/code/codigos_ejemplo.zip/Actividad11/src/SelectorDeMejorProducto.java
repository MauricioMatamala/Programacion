public interface SelectorDeMejorProducto {
    public Producto elegirMejorProducto(LoteDeProductos lote);
}