import javax.swing.*;

public class ActividadesEmpresaForm {
	private JTabbedPane tabPanel;
	private JPanel panel1;
	private JPanel pnlProyectos;
	private JPanel pnlEmpleados;
	private JPanel pnlActividades;
	private JPanel pnlNóminas;
	private JTextField txtNombreEmpleado;
	private JTextField txtDniEmpleado;
	private JButton btnAñadirEmpleado;
	private JComboBox cmbEmpleado;
	private JSpinner spnEdadEmpleado;
	private JList list1;
	private JButton btnAñadirProyecto;
	private JTextField txtFprod;
	private JTextField txtDepartamento;
	private JTextField txtNombreProyecto;
	private JButton btnGuardarProyectos;
	private JList lstProyectos;
	private JSpinner spnHoras;
	private JSpinner spnMinutos;
	private JButton btnAñadirActividad;
	private JComboBox cmbEmpleadosActividades;
	private JComboBox cmbProyectos;
	private JTextArea txtAreaDescripciónActividad;
	private JButton btnGuardarActiciades;
	private JList lstActividades;
	private JButton btnGuardarEmpleados;
	private JComboBox cmbEmpleadosNóminas;
	private JTextField txtSueldoBase;
	private JTextField txtProductividad;
	private JTextField txtSueldoTotal;
	private JButton btnCalcularNómina;
}
