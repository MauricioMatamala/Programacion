package com.politecnico;

public class InterfazHotel {
    public final static int TERMINAR = 0;
    public final static int RESERVAR_HABITACION = 1;
    public final static int VISUALIZAR_HOTEL = 2;
    public final static int BUSCAR_PERSONA_ALOJADA = 3;
    public final static int LIBERAR_HABITACION = 4;
    public final static int MOSTRAR_HABITACIONES_LIBRES = 5;

    // Añadir los métodos auxiliares necesarios.

    public static void main(String[] args) {
        // Crea un nuevo hotel
        // muestra menú principal mientras no se elija la opción terminar.
        // Realiza las tareas necesarias con cada opción.
    }
}