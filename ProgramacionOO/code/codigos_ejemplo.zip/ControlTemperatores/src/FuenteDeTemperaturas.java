public interface FuenteDeTemperaturas {
    public void registrarConsumidor(ConsumidorDeTemperaturas consumidor);
    public void informarAConsumidores();
}
