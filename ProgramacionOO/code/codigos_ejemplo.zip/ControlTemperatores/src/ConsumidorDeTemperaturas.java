public interface ConsumidorDeTemperaturas {
    public void setNuevaTemperatura(double temperatura, int hora);
}
