package com.politecnico;

public interface SalaEsperaChangeListener {
    public void onChangeDo();
}
