package com.politecnico.urgencia;

public class UrgenciaOftalmología extends UrgenciaMedica{
    @Override
    public int getEspecilidad() {
        return Especialidades.OFTALMOLOGÍA;
    }
}
