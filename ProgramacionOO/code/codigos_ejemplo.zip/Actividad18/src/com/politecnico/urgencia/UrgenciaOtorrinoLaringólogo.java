package com.politecnico.urgencia;

public class UrgenciaOtorrinoLaringólogo extends UrgenciaMedica{
    @Override
    public int getEspecilidad() {
        return Especialidades.OTORRINO_LARINGOLOGÍA;
    }
}
