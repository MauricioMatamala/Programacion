package com.politecnico.urgencia;

public class UrgenciaTraumatología extends UrgenciaMedica{
    @Override
    public int getEspecilidad() {
        return Especialidades.TRAUMATOLOGÍA;
    }
}
