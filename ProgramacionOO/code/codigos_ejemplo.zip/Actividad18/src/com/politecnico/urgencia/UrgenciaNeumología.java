package com.politecnico.urgencia;

public class UrgenciaNeumología extends UrgenciaMedica {
    @Override
    public int getEspecilidad() {
        return Especialidades.NEUMOLOGÍA;
    }
}
