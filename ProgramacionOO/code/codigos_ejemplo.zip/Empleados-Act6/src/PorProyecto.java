public class PorProyecto extends Empleado {
    public PorProyecto(String nombre, String apellido, )
}
