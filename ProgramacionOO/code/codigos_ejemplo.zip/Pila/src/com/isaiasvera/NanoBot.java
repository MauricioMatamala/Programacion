package com.isaiasvera;

public class NanoBot extends Robot {
    public String saludo(){
        return "Hola soy un NanoBot";
    }
}
