package com.isaiasvera;

public class MegaBot extends Robot {
    public String saludo(){
        return "Hola, soy un Megabot";
    }
}
