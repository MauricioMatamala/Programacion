package com.isaiasvera;

public class MidBot extends Robot {
    public String saludo(){
       return "Hola soy un Midbot";
    }
}
