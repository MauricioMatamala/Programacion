package com.isaiasvera;

public abstract class Robot {
    public abstract String saludo();
}
