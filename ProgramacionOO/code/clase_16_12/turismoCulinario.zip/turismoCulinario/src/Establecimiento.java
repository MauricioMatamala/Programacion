import java.util.ArrayList;

public class Establecimiento {
    private String nombre;
    private Coordenadas coordenadas;
    private ArrayList<Plato> platos;

    public Establecimiento(String nombre, Coordenadas coordenadas){
        this.nombre = nombre;
        this.coordenadas = coordenadas;
        platos = new ArrayList<Plato>();
    }

    public void addPlato(Plato plato){
        platos.add(plato);
    }

    @Override
    public String toString() {
        return "\n\nEstablecimiento{" +
                "nombre='" + nombre + '\'' +
                ", coordenadas=" + coordenadas +
                ", platos=" + platos +
                '}';
    }
}
