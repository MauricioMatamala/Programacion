public class Plato {
    private String nombre;
    private String descripción;

    public Plato(String nombre, String descripción){
        this.nombre = nombre;
        this.descripción = descripción;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "\n\nPlato{" +
                "nombre='" + nombre + '\'' +
                ", descripción='" + descripción + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        Plato otroPlato = (Plato) obj;
        return nombre.equals(otroPlato.getNombre());
    }
}
