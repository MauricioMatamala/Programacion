import java.util.NoSuchElementException;

public class PlatoNoExistenteException extends NoSuchElementException {
	public PlatoNoExistenteException(String msg) {
		super(msg);
	}
}
