import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ArchivoPlatosCSV {
    private String nombreArchivo;

    public ArchivoPlatosCSV(String nombreArchivo){
        this.nombreArchivo = nombreArchivo;
    }

    public void cargarCiudadesYPlatos(Ciudades ciudades){
        try {
            File archivoCSV = new File(nombreArchivo);
            Scanner lectorArchivo = new Scanner(archivoCSV).useDelimiter("\n");
            while (lectorArchivo.hasNext()){
                String[] lineaCSV = lectorArchivo.next().split(";");
                String nombrePlato = lineaCSV[0];
                String descripciónPlato = lineaCSV[1];
                String nombreCiudad = lineaCSV[2];
                Ciudad ciudad = getCiudadSiExisteOCrearla(nombreCiudad,ciudades);
                Plato plato = new Plato(nombrePlato,descripciónPlato);
                ciudad.addPlato(plato);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private Ciudad getCiudadSiExisteOCrearla(String nombreCiudad, Ciudades ciudades) {
        Ciudad ciudad;
        try {
            ciudad = ciudades.getCiudadPorNombre(nombreCiudad);
        } catch(CiudadNoExistenteException e){
            ciudad = new Ciudad(nombreCiudad);
            ciudades.addCiudad(ciudad);
        }
        return ciudad;
    }


}
