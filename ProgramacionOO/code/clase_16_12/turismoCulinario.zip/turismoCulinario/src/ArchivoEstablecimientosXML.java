import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class ArchivoEstablecimientosXML {
    String nombreArchivo;
    Document doc;

    public ArchivoEstablecimientosXML(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public void abrir() {
        try {
            File inputFile = new File(nombreArchivo);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
    }

    public void cargarEstablecimientoEnCiudades(Ciudades ciudades){
        try {
            XPath xPath = XPathFactory.newInstance().newXPath();
            String xpathExpr = "/establecimientos/establecimiento";
            NodeList nodosEstablecimiento = (NodeList) xPath.compile(xpathExpr).evaluate(doc, XPathConstants.NODESET);
            for (int i=0; i<nodosEstablecimiento.getLength();i++){

                // extracción de datos del elemento 'establecimiento'
                Element elementoEstablecimiento = (Element) nodosEstablecimiento.item(i);
                String nombreCiudad = elementoEstablecimiento.getAttribute("ciudad");
                String nombreEstablecimiento = elementoEstablecimiento.getAttribute("nombre");
                double latitudEstablecimiento = Double.parseDouble(elementoEstablecimiento.getAttribute("latitud"));
                double longitudEstablecimiento = Double.parseDouble(elementoEstablecimiento.getAttribute("longitud"));

                // creación del Establecimiento
                Coordenadas coordenadasEstablecimiento = new Coordenadas(latitudEstablecimiento,longitudEstablecimiento);
                Establecimiento establecimiento = new Establecimiento(nombreEstablecimiento,coordenadasEstablecimiento);

                // carga de platos en Establecimiento
                NodeList nodosPlato = elementoEstablecimiento.getElementsByTagName("plato");
                for (int j=0; j<nodosPlato.getLength(); j++){
                    Element elementoPlato = (Element) nodosPlato.item(j);
                    String nombrePlato = elementoPlato.getAttribute("nombre");
                    Plato plato = ciudades.getCiudadPorNombre(nombreCiudad).getPlatoPorNombre(nombrePlato);
                    establecimiento.addPlato(plato);
                }

                // añadido del establecimiento en la ciudad
                ciudades.getCiudadPorNombre(nombreCiudad).addEstablecimiento(establecimiento);
            }
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
    }
}