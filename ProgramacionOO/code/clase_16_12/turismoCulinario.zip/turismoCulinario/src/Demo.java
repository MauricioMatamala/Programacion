public class Demo {
    public static void main(String[] args) {
        Ciudades ciudades = new Ciudades();

        ArchivoPlatosCSV archivoPlatosCSV = new ArchivoPlatosCSV("platos.csv");
        archivoPlatosCSV.cargarCiudadesYPlatos(ciudades);

        ArchivoEstablecimientosXML archivoEstablecimientosXML = new ArchivoEstablecimientosXML("establecimientos.xml");
        archivoEstablecimientosXML.abrir();
        archivoEstablecimientosXML.cargarEstablecimientoEnCiudades(ciudades);

        System.out.println(ciudades);
    }
}
