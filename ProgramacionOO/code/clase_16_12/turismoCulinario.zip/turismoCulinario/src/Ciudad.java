import java.util.ArrayList;

public class Ciudad {
    private String nombre;
    private ArrayList<Establecimiento> establecimientos;
    private ArrayList<Plato> platos;

    public Ciudad(String nombre){
        this.nombre = nombre;
        establecimientos = new ArrayList<Establecimiento>();
        platos = new ArrayList<Plato>();
    }

    public void addPlato(Plato plato){
        platos.add(plato);
    }

    public void addEstablecimiento(Establecimiento establecimiento){
        establecimientos.add(establecimiento);
    }

    public String getNombre() {
        return nombre;
    }

    public Plato getPlatoPorNombre(String nombrePlato){
        for (Plato plato: platos)
            if (plato.getNombre().equals(nombrePlato))
                return plato;
        throw new PlatoNoExistenteException("El plato " + nombrePlato + " no existe en la ciudad " + nombre);
    }

    @Override
    public String toString() {
        return "\n\nCiudad{" +
                "nombre='" + nombre + '\'' +
                ", establecimientos=" + establecimientos +
                ", platos=" + platos +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        Ciudad otraCiudad = (Ciudad) obj;
        return nombre.equals(otraCiudad.getNombre());
    }
}
