import java.util.ArrayList;

public class Ciudades {
    private ArrayList<Ciudad> ciudades;

    public Ciudades(){
        ciudades = new ArrayList<Ciudad>();
    }

    public Ciudad getCiudadPorNombre(String nombre){
        for (Ciudad ciudad: ciudades)
            if (ciudad.getNombre().equals(nombre))
                return ciudad;
        throw new CiudadNoExistenteException("No existe una ciudad llamada " + nombre);
    }

    public void addCiudad(Ciudad ciudad){
        ciudades.add(ciudad);
    }

    @Override
    public String toString() {
        return "Ciudades{" +
                "ciudades=" + ciudades +
                '}';
    }
}
