package com.politecnico;

import java.util.HashMap;

public interface ExistenciasEscasasListener {
	public void informar(HashMap<Componente,Integer> escasos);
}
