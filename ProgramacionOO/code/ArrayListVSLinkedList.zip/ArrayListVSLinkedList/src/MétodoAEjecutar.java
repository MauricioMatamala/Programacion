public interface MétodoAEjecutar {
    public void ejecutar();
}
