package com.politecnicomalaga.persona;

import java.time.LocalDate;

public class Persona {
    String nombre;
    int edad;
    LocalDate fecha;

    public Persona(String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad;
        fecha = LocalDate.now();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", fecha=" + fecha +
                '}';
    }
}
