package servlet;

import cineforum.FichaPelicula;
import serviciopeliculas.OmdbApiReader;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(
        name="ficha_pelicula",
        urlPatterns = {"/ficha"}
)
public class FichaServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String titulo = req.getParameter("titulo");
        OmdbApiReader Omdb = new OmdbApiReader();
        FichaPelicula ficha = null;
        RequestDispatcher vista;
        try{
            ficha = Omdb.getUrlContent(titulo);
            req.setAttribute("ficha",ficha);
            vista = req.getRequestDispatcher("ficha.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            vista = req.getRequestDispatcher("error.jsp");
        }
        vista.forward(req,resp);
    }
}
