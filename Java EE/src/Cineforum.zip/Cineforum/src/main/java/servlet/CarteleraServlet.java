package servlet;

import cineforum.Cartelera;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(
        name="recomendacion",
        urlPatterns = {"/cartelera"}
)
public class CarteleraServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cartelera cartelera = new Cartelera();
        String genero = req.getParameter("genero");

        String peliculaRecomendada = cartelera.getPeliculaPorGenero(cartelera.nombreGeneroACategoria(genero));

        req.setAttribute("recomendacion",peliculaRecomendada);

        RequestDispatcher vista = req.getRequestDispatcher("cartelera.jsp");
        vista.forward(req,resp);
    }
}
