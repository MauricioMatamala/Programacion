package cineforum;

public class FichaPelicula {
    String titulo = "";
    int año;
    String estreno;
    String duracion;
    String genero;
    String director;
    String pais;
    String cartel;
    String votos;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getEstreno() {
        return estreno;
    }

    public void setEstreno(String estreno) {
        this.estreno = estreno;
    }


    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCartel() {
        return cartel;
    }

    public void setCartel(String cartel) {
        this.cartel = cartel;
    }

    public String getVotos() {
        return votos;
    }

    public void setVotos(String votos) {
        this.votos = votos;
    }

    @Override
    public String toString() {
        return "Pelicula{" +
                "titulo='" + titulo + '\'' +
                ", año=" + año +
                ", estreno=" + estreno +
                ", duracion='" + duracion + '\'' +
                ", genero='" + genero + '\'' +
                ", director='" + director + '\'' +
                ", pais='" + pais + '\'' +
                ", cartel='" + cartel + '\'' +
                ", votos='" + votos + '\'' +
                '}';
    }
}
