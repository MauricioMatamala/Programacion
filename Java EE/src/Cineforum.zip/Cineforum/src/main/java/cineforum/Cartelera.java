package cineforum;

public class Cartelera {
    public final static int ACCION = 0;
    public final static int TERROR = 1;
    public final static int ROMANTICA = 3;
    public final static int COMEDIA = 4;
    public final static int SCI_FI = 5;

    public String getPeliculaPorGenero(int genero){
        switch(genero){
            case ACCION: return "John Wick";
            case TERROR: return "La Cuarentena";
            case ROMANTICA: return "4 Bodas y un funeral";
            case COMEDIA: return "La vida de Bryan";
            default: return "Terminator";
        }
    }

    public int nombreGeneroACategoria(String nombreGenero){
        switch (nombreGenero){
            case "accion": return ACCION;
            case "terror": return TERROR;
            case "romantica": return ROMANTICA;
            case "comedia": return COMEDIA;
            default: return SCI_FI;
        }
    }

}
