package serviciopeliculas;
import cineforum.FichaPelicula;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class OmdbApiReader {
    String documentoXML="";
    Document doc;

    public FichaPelicula getUrlContent(String titulo) throws Exception{
        URL oracle = new URL("http://www.omdbapi.com/?t="+titulo+"&plot=full&r=xml&apikey=21749b24");
        BufferedReader in = new BufferedReader(new InputStreamReader(oracle.openStream()));
        documentoXML = "";
        String inputLine;
        while ((inputLine = in.readLine()) != null)
            documentoXML += inputLine;
        in.close();

        parseXML();
        return getFicha();
    }

    public void parseXML(){
        String dir = System.getProperty("user.dir");
        System.out.println(dir);
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(new InputSource(new StringReader(documentoXML)));
            doc.getDocumentElement().normalize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public FichaPelicula getFicha() throws XPathExpressionException {
        XPath xPath = XPathFactory.newInstance().newXPath();
        String xpathExpr = "/root/movie";
        NodeList nodeList = (NodeList) xPath.compile(xpathExpr).evaluate(doc, XPathConstants.NODESET);
        FichaPelicula pelicula = null;
        Element elementoPelicula;
        if (nodeList.getLength() > 0){
            elementoPelicula = (Element) nodeList.item(0);
            pelicula = new FichaPelicula();
            pelicula.setAño(Integer.parseInt(elementoPelicula.getAttribute("year")));
            pelicula.setCartel(elementoPelicula.getAttribute("poster"));
            pelicula.setDirector("director");
            pelicula.setDuracion(elementoPelicula.getAttribute("runtime"));
            pelicula.setEstreno(elementoPelicula.getAttribute("released"));
            pelicula.setGenero(elementoPelicula.getAttribute("genre"));
            pelicula.setPais(elementoPelicula.getAttribute("country"));
            pelicula.setTitulo(elementoPelicula.getAttribute("title"));
            pelicula.setVotos(elementoPelicula.getAttribute("imdbRating"));
        }
        return pelicula;
    }
}
