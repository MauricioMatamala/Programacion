package org.example.controlador;

import org.example.dao.UsuarioDAO;
import org.example.modelo.Usuario;

import java.sql.SQLException;

public class ControladorUsuarios {
    public boolean crearUsuario(String nombre, int edad) throws SQLException {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        return usuarioDAO.create(new Usuario(nombre,edad));
    }
}
