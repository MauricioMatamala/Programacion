package org.example.vista;

import org.example.controlador.ControladorUsuarios;
import org.example.dao.UsuarioDAO;
import org.example.modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class VistaInsertar {
    private JTextField txtNombre;
    private JButton btnInsertar;
    private JSpinner spnEdad;
    private JLabel lblResultado;
    private JPanel pnlMain;
    private ControladorUsuarios controladorUsuarios;
    public VistaInsertar(){
        controladorUsuarios = new ControladorUsuarios();

        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String nombre = txtNombre.getText();
                int edad = (Integer) spnEdad.getValue();
                try {
                    boolean resultado = controladorUsuarios.crearUsuario(nombre,edad);
                    if (resultado == true)
                        lblResultado.setText("Operación exitosa");
                    else
                        lblResultado.setText("Operación fallida");
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                    lblResultado.setText("Hubo un error con la base de datos");
                }
            }
        });
    }

    public Container getPanel() {
        return pnlMain;
    }
}
