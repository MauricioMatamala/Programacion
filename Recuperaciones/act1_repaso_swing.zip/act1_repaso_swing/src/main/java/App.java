import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) throws SQLException {
        Usuario usuario1 = new Usuario("Pedro García",33);
        Usuario usuario2 = new Usuario("Carlos Orozco",15);
        Usuario usuario3 = new Usuario("Ana López",21);

        Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Usuarios?serverTimezone=UTC","usuariosuser","Perro20");

        // Apartado 1
        dbConn.prepareStatement("INSERT INTO usuarios(nombre,edad) VALUES ('"+usuario1.getNombre()+"','"+usuario1.getEdad()+"')").executeUpdate();
        dbConn.prepareStatement("INSERT INTO usuarios(nombre,edad) VALUES ('"+usuario2.getNombre()+"','"+usuario2.getEdad()+"')").executeUpdate();
        dbConn.prepareStatement("INSERT INTO usuarios(nombre,edad) VALUES ('"+usuario3.getNombre()+"','"+usuario3.getEdad()+"')").executeUpdate();

        // Apartado 2
        List<Usuario> lista = new ArrayList<>();
        ResultSet result = dbConn.prepareStatement("SELECT * FROM usuarios").executeQuery();
        while (result.next()){
            Usuario usuario = new Usuario(result.getString("nombre"),result.getInt("edad"));
            usuario.setId(result.getInt("id"));
            lista.add(usuario);
        }
        System.out.println(lista);

        // Apartado 3
        dbConn.prepareStatement("UPDATE usuarios SET edad='23' WHERE nombre='Pedro García'").executeUpdate();

        // Apartado 4
        dbConn.prepareStatement("DELETE FROM usuarios WHERE nombre='Ana López'").executeUpdate();
    }
}
