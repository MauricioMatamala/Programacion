package ConfReader;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;

public class ConfReaderXML extends ConfReader{

    public ConfReaderXML(String fileName) {
        super(fileName);
    }

    @Override
    public String readParam(String paramName) {
        String paramValue = "";
        try {
            File inputFile = new File(getFile());
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(getFile());
            doc.getDocumentElement().normalize();

            XPath xPath = XPathFactory.newInstance().newXPath();
            String xpathExpr = "/configuration/conf[@param='"+paramName+"']";
            NodeList nodeList = (NodeList) xPath.compile(xpathExpr).evaluate(doc, XPathConstants.NODESET);

            if (nodeList.getLength() > 0) {
                Element paramElement = (Element) nodeList.item(0);
                paramValue = paramElement.getAttribute("value");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return paramValue;
    }
}
