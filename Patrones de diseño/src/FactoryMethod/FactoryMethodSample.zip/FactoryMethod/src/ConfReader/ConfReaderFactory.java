package ConfReader;

import java.io.File;

public class ConfReaderFactory {
    public static ConfReader createConfReader(String fileName){
        String checkedFile = fileName;
        if (fileNotFound(fileName))
            checkedFile = "default_conf.xml";
        switch (getFileExtension(checkedFile)){
            case "xml": return new ConfReaderXML(checkedFile);
            case "csv": return new ConfReaderCSV(checkedFile);
            default: return new ConfReaderXML(checkedFile);
        }
    }

    private static boolean fileNotFound(String fileName){
        File file = new File(fileName);
        return !file.exists();
    }

    private static String getFileExtension(String fileName){
        String[] fileNameParts = fileName.split("\\.");
        return fileNameParts[fileNameParts.length-1];
    }
}
