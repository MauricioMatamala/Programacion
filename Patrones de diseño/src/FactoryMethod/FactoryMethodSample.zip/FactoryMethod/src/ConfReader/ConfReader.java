package ConfReader;

public abstract class ConfReader {
    private String fileName;

    public ConfReader(String fileName){
        this.fileName = fileName;
    }

    public String getFile(){
        return fileName;
    }

    public abstract String readParam(String paramName);
}
