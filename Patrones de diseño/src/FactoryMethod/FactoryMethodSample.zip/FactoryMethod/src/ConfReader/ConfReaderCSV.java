package ConfReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ConfReaderCSV extends ConfReader{

    public ConfReaderCSV(String fileName) {
        super(fileName);
    }

    @Override
    public String readParam(String paramName) {
        String parameterValue = "";
        try {
            File file = new File(getFile());
            Scanner scanner = new Scanner(file).useDelimiter("\n");
            String[] listOfParameters = scanner.next().split(";");
            int parameterColumn = getParameterColumn(listOfParameters,paramName);
            if (parameterColumn > -1) {
                String[] parameterValues = scanner.next().split(";");
                parameterValue = parameterValues[parameterColumn];
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return parameterValue;
    }

    private int getParameterColumn(String[] parametersName, String param){
        for (int i=0; i<parametersName.length; i++){
            if (parametersName[i].equals(param))
                return i;
        }
        return -1;
    }
}
