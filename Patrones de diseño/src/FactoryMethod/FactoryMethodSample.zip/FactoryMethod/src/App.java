import ConfReader.ConfReader;
import ConfReader.ConfReaderFactory;
import java.util.Scanner;

/**
 * EXPLICACIÓN DEL PROYECTO
 *
 * Este proyecto es una aplicación práctica del patrón Factory Method. El patrón Factory Method
 * es un patrón creacional que permite a un cliente crear dinámicamente el objeto adecuado dependiendo
 * de las circunstancias, abstrayéndolo de los detalles.
 *
 * En este ejemplo, el cliente (main) necesita obtener el valor de dos parámetros (width y height)
 * de un archivo de configuración, aunque en tiempo de compilación no se conoce de qué tipo será (xml o csv). Los archivos de configuración en el ejemplo son:
 *
 * Los archivos de configuración incluidos con el proyectos son:
 * - window_conf.csv
 *      - la primera línea incluye los nombres de los parámetros.
 *      - la segunda línea incluye los valores de los parámetros.
 * - window_conf.xml
 *      - Contiene los valores en una estructura del siguiente tipo:
 *          <configuration>
 *              <conf param="nombre_parámetro" value="valor_del_parámetro"/>
 *          </configuration>
 * - default_conf.xml
 *      - Si el archivo indicado no existe, se utiliza este archivo, con una estructura
 *        similar al anterior.
 *
 * Descripción de las clases
 * - App - clase cliente del patrón Factory
 * - ReaderFactory - clase Factory que devuelve el tipo apropiado de ConfReader
 * - ConfReader - clase abstracta que cumple el papel de Producto en el patrón Factory Methodd
 * - ConfReaderXML y ConfReaderCSV - clase concreta que cumple el papel de ProductoConcreto en el patrón Factory Method
 *
 */

public class App {
    public static void main(String[] args) {
        // Para simular la impredecibilidad del archivo de configuración
        // se pide un nombre de archivo por pantalla.
        Scanner keyReader = new Scanner(System.in).useDelimiter("\n");
        System.out.print("File name: ");
        String fileName = keyReader.next();
        //-----------------------------------------

        ConfReader confReader = ConfReaderFactory.createConfReader(fileName);

        // Comprobación de los parámetros:
        System.out.println("width = " + confReader.readParam("width"));
        System.out.println("height = " + confReader.readParam("height"));
        System.out.println("NoExiste = " + confReader.readParam("NoExiste"));
    }
}
