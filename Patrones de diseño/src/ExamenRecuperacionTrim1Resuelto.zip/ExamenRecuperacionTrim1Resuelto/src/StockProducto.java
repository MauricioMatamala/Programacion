import java.util.Objects;

public class StockProducto {
    private int unidades;
    private int umbral;
    private Producto producto;

    public StockProducto(Producto producto, int unidades, int umbral){
        this.producto = producto;
        this.unidades = unidades;
        this.umbral = umbral;
    }

    public String getRef() {
        return producto.getRef();
    }

    public Producto getProducto() {
        return producto;
    }

    public String getNombre() {
        return producto.getNombre();
    }

    public int getUnidades() {
        return unidades;
    }

    public int getUmbral() {
        return umbral;
    }

    public void sacarStock(int cantidad) {
        this.unidades -= cantidad;
    }

    @Override
    public boolean equals(Object objeto) {
        StockProducto stockProducto = (StockProducto) objeto;
        return producto.getNombre().equals(stockProducto.getNombre());
    }
}
