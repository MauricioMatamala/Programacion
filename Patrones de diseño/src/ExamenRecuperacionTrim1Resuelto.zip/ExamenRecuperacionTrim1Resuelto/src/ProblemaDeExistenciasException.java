public class ProblemaDeExistenciasException extends IllegalStateException {
    public ProblemaDeExistenciasException(String mensaje) {
        super(mensaje);
    }
}
