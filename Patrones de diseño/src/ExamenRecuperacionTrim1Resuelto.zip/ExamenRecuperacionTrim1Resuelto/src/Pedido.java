public class Pedido {
    private int cantidad;
    private Producto producto;

    public Pedido (int cantidad, Producto producto){
        this.cantidad = cantidad;
        this.producto = producto;
    }


    public String getNombre() {
        return producto.getNombre();
    }

    public int getCantidad(){
        return cantidad;
    }
}
