public class Producto {
    private String nombre;
    private String ref;
    private double precio;

    public Producto(String nombre, String ref, double precio){
        this.nombre = nombre;
        this.ref = ref;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "nombre='" + nombre + '\'' +
                ", ref='" + ref + '\'' +
                ", precio=" + precio +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public String getRef() {
        return ref;
    }
}
