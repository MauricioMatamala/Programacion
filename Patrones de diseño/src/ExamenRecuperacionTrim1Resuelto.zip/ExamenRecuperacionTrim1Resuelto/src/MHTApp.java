import java.util.ArrayList;

public class MHTApp {
    private ArrayList<Cliente> clientes;
    private ControlDeAlmacen controlDeAlmacen;
    private Almacen almacen;

    public MHTApp(ArrayList<Cliente> clientes, ControlDeAlmacen controlDeAlmacen, Almacen almacen){
        this.almacen = almacen;
        this.controlDeAlmacen = controlDeAlmacen;
        this.clientes = clientes;
    }

    public ArrayList<StockProducto> getProductosAlmacen(){
        return almacen.getStockProductos();
    }

    public StockProducto getStockProductoByRef(String ref) {
        return almacen.getStockProductoByRef(ref);
    }

    public void hacerPedido(String nombreCliente, String ref, int cantidad) throws ProblemaDeExistenciasException{
        StockProducto stockProducto = almacen.getStockProductoByRef(ref);
        if (stockProducto.getUnidades() > cantidad){
            Cliente cliente = getClienteByNombre(nombreCliente);
            cliente.addPedido(new Pedido(cantidad,stockProducto.getProducto()));
            stockProducto.sacarStock(cantidad);
            if (stockProducto.getUnidades() < stockProducto.getUmbral()) {
                controlDeAlmacen.crearOrdenDeReposicion(stockProducto);
                throw new ProblemaDeExistenciasException("El stock está demasiado bajo para el producto " + stockProducto.getNombre());
            }
        } else {
            controlDeAlmacen.crearOrdenDeReposicion(stockProducto);
            throw new ProblemaDeExistenciasException("No quedan suficientes existencias para vender " + cantidad + " unidades del producto "+ stockProducto.getNombre());
        }
    }

    public Cliente getClienteByNombre(String nombreCliente) {
        for (Cliente cliente : clientes) {
            if (cliente.getNombre().equals(nombreCliente))
                return cliente;
        }
        return null;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }


    public ArrayList<StockProducto> getOrdenesReposicion() {
        return controlDeAlmacen.getOrdenesReposicion();
    }
}
