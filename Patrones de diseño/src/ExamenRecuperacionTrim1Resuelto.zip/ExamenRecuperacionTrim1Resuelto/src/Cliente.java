import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private ArrayList<Pedido> pedidos;
    public Cliente(String nombre){
        this.nombre = nombre;
        pedidos = new ArrayList<>();
    }

    public void addPedido(Pedido pedido){
        pedidos.add(pedido);
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", pedidos=" + pedidos +
                '}';
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }
}
