import java.util.ArrayList;

public class Almacen {
    private ArrayList<StockProducto> stockProductos;

    public Almacen(ArrayList<StockProducto> stockProductos){
        this.stockProductos = stockProductos;
    }

    public ArrayList<StockProducto> getStockProductos(){
        return stockProductos;
    }

    public StockProducto getStockProductoByRef(String ref) {
        for (StockProducto stockProducto : stockProductos){
            if (stockProducto.getRef().equals(ref))
                return stockProducto;
        }
        return null;
    }
}
