import java.util.ArrayList;

public class ControlDeAlmacen {
    private ArrayList<StockProducto> ordenesDeReposicion;

    public ControlDeAlmacen(){
        ordenesDeReposicion = new ArrayList<>();
    }

    public void crearOrdenDeReposicion(StockProducto stockProducto){
        if (!ordenesDeReposicion.contains(stockProducto))
            ordenesDeReposicion.add(stockProducto);
    }

    public ArrayList<StockProducto> getOrdenesReposicion() {
        return ordenesDeReposicion;
    }
}
