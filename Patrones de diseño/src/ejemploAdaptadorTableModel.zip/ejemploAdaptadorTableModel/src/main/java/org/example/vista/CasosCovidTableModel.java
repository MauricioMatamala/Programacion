package org.example.vista;

import org.example.modelo.CasosCovid;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class CasosCovidTableModel extends AbstractTableModel {
    private final static int COLUMNA_PAIS = 0;
    private final static int COLUMNA_FECHA = 1;
    private final static int COLUMNA_CASOS = 2;


    private List<CasosCovid> listaCasos;
    private String[] nombreColumnas = {"País","Fecha (dd/mm/aaaa)","Nuevos casos"};

    public CasosCovidTableModel(List<CasosCovid> listaCasos){
        this.listaCasos = listaCasos;
    }

    @Override
    public int getRowCount() {
        return listaCasos.size();
    }

    @Override
    public int getColumnCount() {
        return nombreColumnas.length;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        if ((fila > -1) && (fila < listaCasos.size())){
            switch(columna){
                case COLUMNA_PAIS: return listaCasos.get(fila).getNombrePais();
                case COLUMNA_FECHA: return listaCasos.get(fila).getFecha();
                case COLUMNA_CASOS: return listaCasos.get(fila).getCasos();
            }
        }
        return null;
    }

    @Override
    public String getColumnName(int column) {
        return nombreColumnas[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex){
            case COLUMNA_PAIS:
            case COLUMNA_FECHA: return String.class;
            case COLUMNA_CASOS: return Integer.class;
        }
        return null;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

        if ((rowIndex > -1) && (rowIndex < listaCasos.size())){
            if (columnIndex == COLUMNA_PAIS) listaCasos.get(rowIndex).setNombrePais((String) aValue);
            else if (columnIndex == COLUMNA_FECHA) listaCasos.get(rowIndex).setFecha((String) aValue);
            else if (columnIndex == COLUMNA_CASOS) listaCasos.get(rowIndex).setCasos((Integer) aValue);
        }
        fireTableCellUpdated(rowIndex,columnIndex);
    }

    public void removeRow(int row){
        if ((row > -1) && (row < listaCasos.size())){
            int confirmacionBorrar = JOptionPane.showConfirmDialog(null,"¿Desea borrar la fila?","Borrado",JOptionPane.WARNING_MESSAGE);
            if (confirmacionBorrar == JOptionPane.OK_OPTION) {
                listaCasos.remove(row);
                fireTableRowsDeleted(row,row);
            }
        }
    }

    public void addRow(){
        listaCasos.add(new CasosCovid("","01/01/2020",0));
        fireTableDataChanged();
    }
}
