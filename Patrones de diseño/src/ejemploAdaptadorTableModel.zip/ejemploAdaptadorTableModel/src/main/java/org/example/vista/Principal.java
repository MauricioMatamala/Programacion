package org.example.vista;

import org.example.modelo.CasosCovid;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

public class Principal {
    private JTable tblCovid;
    private JButton btnPrintConsola;
    private JButton btnInsertar;
    private JPanel pnlMain;
    private JButton btnBorrar;
    CasosCovidTableModel covidTableModel;
    List<CasosCovid> listaCasos;

    public Principal(List<CasosCovid> listaCasos){
        this.listaCasos = listaCasos;
        covidTableModel = new CasosCovidTableModel(listaCasos);
        tblCovid.setModel(covidTableModel);

        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                covidTableModel.addRow();
            }
        });

        btnPrintConsola.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println(listaCasos);
            }
        });

        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                covidTableModel.removeRow(tblCovid.getSelectedRow());
            }
        });

        tblCovid.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE){
                    tblCovid.getCellEditor().stopCellEditing();
                    covidTableModel.removeRow(tblCovid.getSelectedRow());
                }
            }
        });
    }

    public JPanel getPanel() {
        return pnlMain;
    }
}
