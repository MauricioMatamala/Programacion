package org.example;

import org.example.modelo.CasosCovid;
import org.example.vista.Principal;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        List<CasosCovid> listaCasosCovid = crearLista();

        JFrame frame = new JFrame("Covid"); // Marco de la aplicación.
        frame.setContentPane(new Principal(listaCasosCovid).getPanel()); // Alturas: nombre del Form enmarcado y de su clase correspondiente.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static List<CasosCovid> crearLista() {
        List<CasosCovid> lista = new ArrayList<>(){
            @Override
            public String toString() {
                String resultado = "\n-----------------------------------";
                resultado += "\nEstado de la lista";
                for (CasosCovid casos: this)
                    resultado += "\n" + casos.toString();
                return resultado;
            }
        };

        lista.add(new CasosCovid("España","03/04/2020",3000));
        lista.add(new CasosCovid("Italia","03/04/2020",4000));
        lista.add(new CasosCovid("UK","03/04/2020",3500));
        lista.add(new CasosCovid("Alemania","03/04/2020",3200));
        lista.add(new CasosCovid("Lituania","03/04/2020",300));
        lista.add(new CasosCovid("Grecia","03/04/2020",2000));
        lista.add(new CasosCovid("EEUU","03/04/2020",25000));
        return lista;
    }
}
