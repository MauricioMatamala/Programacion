package org.example.modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CasosCovid {
    private String nombrePais;
    private LocalDate fecha;
    private int casos;

    private DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public CasosCovid(String nombrePais, String fecha, int casos) {
        this.nombrePais = nombrePais;
        this.fecha = LocalDate.parse(fecha,formatoFecha);
        this.casos = casos;
    }

    public String getNombrePais() {
        return nombrePais;
    }

    public void setNombrePais(String nombrePais) {
        this.nombrePais = nombrePais;
    }

    public String getFecha() {
        return fecha.format(formatoFecha);
    }

    public void setFecha(String fecha){
        this.fecha = LocalDate.parse(fecha,formatoFecha);
    }

    public int getCasos() {
        return casos;
    }

    public void setCasos(int casos) {
        this.casos = casos;
    }

    @Override
    public String toString() {
        return nombrePais + ", " + casos + " nuevos casos en la fecha " + fecha.format(formatoFecha);
    }
}
