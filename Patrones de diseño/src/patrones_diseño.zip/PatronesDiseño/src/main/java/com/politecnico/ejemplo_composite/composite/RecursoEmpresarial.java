package com.politecnico.ejemplo_composite.composite;

public interface RecursoEmpresarial {
    public static final int UNIDAD_ORGANIZATIVA = 0;
    public static final int EMPLEADO = 1;

    public String getNombre();
    public double calcularCosteSueldo();
    public String toString();
    public int getTipo();
}
