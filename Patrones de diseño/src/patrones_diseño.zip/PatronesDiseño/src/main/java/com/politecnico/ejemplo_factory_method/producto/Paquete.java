package com.politecnico.ejemplo_factory_method.producto;

public class Paquete implements Envio {
    @Override
    public String getTipo() {
        return "Paquete";
    }
}
