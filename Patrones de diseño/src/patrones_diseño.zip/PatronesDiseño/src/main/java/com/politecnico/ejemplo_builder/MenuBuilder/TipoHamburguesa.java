package com.politecnico.ejemplo_builder.MenuBuilder;

public enum TipoHamburguesa {
    NORMAL,
    CON_QUESO,
    COMPLETA,
    DOBLE,
    DOBLE_COMPLETA,
    CHEESE_BACON,
    HERCULES,
    GODZILLA
}
