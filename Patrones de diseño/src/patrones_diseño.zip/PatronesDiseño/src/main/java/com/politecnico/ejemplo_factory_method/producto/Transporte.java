package com.politecnico.ejemplo_factory_method.producto;

public interface Transporte {
    public final static int CAMIÓN = 1;
    public final static int BARCO = 2;

    public String getTipoTransporte();
    public Envio getEnvio();
}
