package com.politecnico.ejemplo_composite;

import com.politecnico.ejemplo_composite.builder_helper.RecursoEmpresarialBuilder;
import com.politecnico.ejemplo_composite.composite.Empleado;
import com.politecnico.ejemplo_composite.composite.RecursoEmpresarial;
import com.politecnico.ejemplo_composite.composite.UnidadOrganizativa;

public class App {
    public static void main(String[] args) {
        RecursoEmpresarialBuilder builder = new RecursoEmpresarialBuilder("Málaga");
        builder.iniciarUnidadOrganizativa("PTA")
                    .iniciarUnidadOrganizativa("Call Center")
                        .addEmpleado("EmpCallPta1",1800)
                        .addEmpleado("EmpCallPta2",1800)
                        .addEmpleado("EmpCallPta3",2000)
                    .finalizarUnidadOrganizativa()
                    .iniciarUnidadOrganizativa("Desarrollo")
                        .addEmpleado("DesPta1",2500)
                        .addEmpleado("DesPta2",3000)
                        .addEmpleado("DesPta3",3200)
                        .addEmpleado("DesPta4",2000)
                    .finalizarUnidadOrganizativa()
                .finalizarUnidadOrganizativa()
                .iniciarUnidadOrganizativa("Larios")
                    .iniciarUnidadOrganizativa("Ventas")
                        .addEmpleado("VenLar1",1800)
                        .addEmpleado("VenLar2",2800)
                        .addEmpleado("VenLar3",4000)
                    .finalizarUnidadOrganizativa()
                    .iniciarUnidadOrganizativa("Tesorería")
                        .addEmpleado("TesLar1",2000)
                        .addEmpleado("TesLar2",2300)
                    .finalizarUnidadOrganizativa()
                .finalizarUnidadOrganizativa()
            .finalizarUnidadOrganizativa();

        RecursoEmpresarial recurso = builder.getResultado();
        System.out.println(recurso.toString());

        // Sueldo a pagar al departamento de Desarrollo:

        RecursoEmpresarial dptoDesarrollo = ((UnidadOrganizativa) recurso).getRecursoEmpresarialPorNombre("Desarrollo");
        System.out.println("El sueldo a pagar en el departamento de desarrollo es de " + dptoDesarrollo.calcularCosteSueldo() + " €");

        // Sueldo a pagar en el PTA

        RecursoEmpresarial PTA = ((UnidadOrganizativa) recurso).getRecursoEmpresarialPorNombre("PTA");
        System.out.println("El sueldo a pagar en el PTA es de " + PTA.calcularCosteSueldo() + " €");

        // Sueldo a pagar en toda la empresa

        System.out.println("El sueldo a pagar en la empresa es de " + recurso.calcularCosteSueldo() + " €");
    }
}
