package com.politecnico.ejemplo_abstract_factory.producto;

public class BatidoVainilla implements Bebida {
    @Override
    public String getNombreBebida() {
        return "batido de fresa";
    }
}
