package com.politecnico.ejemplo_abstract_factory.abstract_factory;

import com.politecnico.ejemplo_abstract_factory.producto.*;

public class DesayunoFactory implements ComidaFactory {
    @Override
    public Comida crearComida() {
        return new Tostada();
    }

    @Override
    public Bebida crearBebida() {
        return new Café();
    }

    @Override
    public Salsa crearSalsa() {
        return new AceiteOliva();
    }
}
