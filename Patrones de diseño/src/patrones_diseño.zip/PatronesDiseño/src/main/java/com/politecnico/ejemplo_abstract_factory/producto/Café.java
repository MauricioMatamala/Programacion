package com.politecnico.ejemplo_abstract_factory.producto;

public class Café implements Bebida{

    @Override
    public String getNombreBebida() {
        return "café";
    }
}
