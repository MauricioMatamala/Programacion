package com.politecnico.ejemplo_abstract_factory.producto;

public class AceiteOliva implements Salsa {
    @Override
    public String getNombreSalsa() {
        return "aceite de oliva";
    }
}
