package com.politecnico.ejemplo_abstract_factory.producto;

public class Ketchup implements Salsa {
    @Override
    public String getNombreSalsa() {
        return "ketchup";
    }
}
