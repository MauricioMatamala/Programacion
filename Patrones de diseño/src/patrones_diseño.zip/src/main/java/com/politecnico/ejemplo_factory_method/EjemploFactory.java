package com.politecnico.ejemplo_factory_method;

import com.politecnico.ejemplo_factory_method.factory_method.PlanDeTransporte;
import com.politecnico.ejemplo_factory_method.factory_method.PlanDeTransportePorCarretera;
import com.politecnico.ejemplo_factory_method.factory_method.PlanDeTransportePorMar;
import com.politecnico.ejemplo_factory_method.producto.Transporte;

public class EjemploFactory {

    private static int configuracion_transporte = Transporte.BARCO;
    private static PlanDeTransporte planDeTransporte;

    public static void main(String[] args) {
        inicializar();
        Transporte transporte = planDeTransporte.crearTransporte();
        System.out.println("El transporte es: " + transporte.getTipoTransporte());
        System.out.println("El envío es: " + transporte.getEnvio().getTipo());
    }


    public static void inicializar(){
        // Este método debe ejecutarse una única vez para decidir el tipo de PlanDeTransporte.
        // El objeto resultante (planDeTransporte) debe ser inyectado donde se necesite crear un nuevo transporte.

        if (configuracion_transporte == Transporte.BARCO)
            planDeTransporte = new PlanDeTransportePorMar();
        else if (configuracion_transporte == Transporte.CAMIÓN)
            planDeTransporte = new PlanDeTransportePorCarretera();
        else
            throw new IllegalArgumentException("No existe ese método de transporte");
    }
}
