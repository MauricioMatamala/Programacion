package com.politecnico.ejemplo_factory_method.factory_method;

import com.politecnico.ejemplo_factory_method.producto.Barco;
import com.politecnico.ejemplo_factory_method.producto.Transporte;

public class PlanDeTransportePorCarretera implements PlanDeTransporte {
    @Override
    public Transporte crearTransporte() {
        return new Barco();
    }
}
