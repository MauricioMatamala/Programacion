package com.politecnico.ejemplo_factory_method.producto;

public class Camión implements Transporte {
    Envio envio;

    public Camión(){
        envio = new Paquete();
    }

    @Override
    public String getTipoTransporte() {
        return "Camión";
    }

    @Override
    public Envio getEnvio() {
        return envio;
    }
}
