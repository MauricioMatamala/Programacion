package com.politecnico.ejemplo_factory_method.factory_method;

import com.politecnico.ejemplo_factory_method.producto.Camión;
import com.politecnico.ejemplo_factory_method.producto.Transporte;

public class PlanDeTransportePorMar implements PlanDeTransporte {
    @Override
    public Transporte crearTransporte() {
        return new Camión();
    }
}
