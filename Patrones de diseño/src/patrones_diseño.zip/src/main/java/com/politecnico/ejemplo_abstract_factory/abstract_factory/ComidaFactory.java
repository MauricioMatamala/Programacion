package com.politecnico.ejemplo_abstract_factory.abstract_factory;

import com.politecnico.ejemplo_abstract_factory.producto.Bebida;
import com.politecnico.ejemplo_abstract_factory.producto.Comida;
import com.politecnico.ejemplo_abstract_factory.producto.Salsa;

public interface ComidaFactory {
    public Comida crearComida();
    public Bebida crearBebida();
    public Salsa crearSalsa();

}
