package com.politecnico.ejemplo_abstract_factory.producto;

public class Gofre implements Comida {
    @Override
    public String getNombreComida() {
        return "gofre";
    }
}
