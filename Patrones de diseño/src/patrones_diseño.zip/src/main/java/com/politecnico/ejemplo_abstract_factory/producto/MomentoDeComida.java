package com.politecnico.ejemplo_abstract_factory.producto;

public enum MomentoDeComida {
    DESAYUNO,
    ALMUERZO,
    MERIENDA
}
