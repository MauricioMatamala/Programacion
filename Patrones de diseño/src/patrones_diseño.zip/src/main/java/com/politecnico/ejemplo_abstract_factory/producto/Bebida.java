package com.politecnico.ejemplo_abstract_factory.producto;

public interface Bebida {
    public String getNombreBebida();
}
