package com.politecnico.ejemplo_abstract_factory.producto;

public class SiropeFresa implements Salsa {

    @Override
    public String getNombreSalsa() {
        return "sirope de fresa";
    }
}
