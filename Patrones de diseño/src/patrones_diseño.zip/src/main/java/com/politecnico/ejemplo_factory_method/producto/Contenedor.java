package com.politecnico.ejemplo_factory_method.producto;

public class Contenedor implements Envio{
    @Override
    public String getTipo() {
        return "Contenedor";
    }
}
