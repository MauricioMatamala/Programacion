import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UI {
    private JTextField txtSuma;
    private JButton btnSuma;
    private JLabel lblSuma;
    private JPanel pnlSuma;
    private Suma suma;

    public UI(){
        btnSuma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                suma.sumar(Integer.parseInt(txtSuma.getText()));
            }
        });
    }

    public void setSuma(Suma suma){
        this.suma = suma;
    }

    public JPanel getPanel(){
        return pnlSuma;
    }

    public AvisadorCambioSuma avisador = new AvisadorCambioSuma() {
        @Override
        public void avisar(Suma suma) {
            lblSuma.setText(String.valueOf(suma.getSumaTotal()));
        }
    };
}
