import java.util.Scanner;

public class TxtUI {
    private Scanner lectorTeclado;
    private Suma suma;

    public TxtUI(){
        lectorTeclado = new Scanner(System.in).useDelimiter("\n");
    }

    public void mostrarMenu(){
        while(true) {
            System.out.print("Introduce un número: ");
            suma.sumar(lectorTeclado.nextInt());
        }
    }

    public void setSuma(Suma suma){
        this.suma = suma;
    }

    public AvisadorCambioSuma avisador = new AvisadorCambioSuma() {
        @Override
        public void avisar(Suma suma) {
            System.out.println("La nueva suma es " + suma.getSumaTotal());
        }
    };
}
