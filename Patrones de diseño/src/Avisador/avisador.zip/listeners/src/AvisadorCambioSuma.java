public interface AvisadorCambioSuma {
    public void avisar(Suma suma);
}
