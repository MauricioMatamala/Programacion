public class AppSuma {
    public static void main(String[] args) {
        Suma suma = new Suma();
        TxtUI ui = new TxtUI();
        suma.setAvisadorCambioSuma(ui.avisador);
        ui.setSuma(suma);

        ui.mostrarMenu();

        /*UI ui = new UI();
        suma.setAvisadorCambioSuma(ui.avisador);
        ui.setSuma(suma);

        JFrame frame = new JFrame("Sumas");
        frame.setContentPane(ui.getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        int height = toolkit.getScreenSize().height - 200;
        int width = toolkit.getScreenSize().width - 400;
        frame.setPreferredSize(new Dimension(width, height));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);*/
    }
}
