package modelo;

public class Caja {
}
