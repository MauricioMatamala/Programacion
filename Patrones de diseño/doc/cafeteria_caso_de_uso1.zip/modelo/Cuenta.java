package modelo;

public class Cuenta {
}
