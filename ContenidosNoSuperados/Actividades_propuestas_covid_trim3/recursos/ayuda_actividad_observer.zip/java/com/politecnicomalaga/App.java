package com.politecnicomalaga;

import com.politecnicomalaga.sensor.SensorTemperatura;

import java.util.Timer;

public class App 
{
    public static void main( String[] args )
    {
        Timer temporizador = new Timer();
        SensorTemperatura sensor = new SensorTemperatura();
        temporizador.schedule(sensor,0,5000);


    }
}
